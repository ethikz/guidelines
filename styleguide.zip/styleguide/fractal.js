/* eslint no-console: 0 */
var op = require( 'openport' ),
    fractal = require( '@frctl/fractal' ).create(),
    mandelbrot = require( '@frctl/mandelbrot' ),
    lexiconTheme = mandelbrot({
      skin: 'red',
      format: 'yaml',
      styles: [
        'default',
        '../../css/theme.css'
      ],
      scripts: [
        'default',
        '../../js/theme.min.js'
      ],
      nav: [ 'docs', 'components' ]
    }),
    hbs = require( '@frctl/handlebars' )({
      helpers: {
        uppercase: function( str ) {
          return str.toUpperCase();
        },
        times: function( n, block ) {
          var accum = '',
              i;

          for ( i = 0; i < n; ++i ) {
            accum += block.fn( i + 1 );
          }

          return accum;
        },
        ifEq: function( arg1, arg2, options ) {
          return ( arg1 == arg2 ) ? options.fn( this ) : options.inverse( this );
        },
        getJsonContext: function( data, options ) {
          return options.fn( JSON.parse( data ) );
        },
        concat: function() {
          var outStr = '',
              arg = null;

          for ( arg in arguments ) {
            if ( typeof arguments[arg] != 'object' ) {
              outStr += arguments[arg];
            }
          }
          return outStr;
        }
      }
    }),
    fs = require( 'fs-extra' );

// Used to allow custom parameters on documentation pages, i.e. 'description'
fs.copy( path.resolve( __dirname, './entity.js' ), './node_modules/@frctl/fractal/src/core/mixins/entity.js' );

// set as the default template engine for components
fractal.components.engine( hbs );
fractal.docs.engine( hbs );

// Taken from fractal documentation
const instance = fractal.components.engine();

// Using handlebars-layouts (https://github.com/shannonmoeller/handlebars-layouts)
const layouts = require( 'handlebars-layouts' );

layouts.register( instance.handlebars );

// title for the project
fractal.set( 'project.title', 'Digital Lexicon' );
fractal.set( 'project.version', 'v1.0' );

// destination for the static export
fractal.web.set( 'builder.dest', __dirname + '/build' );
fractal.web.set( 'static.path', __dirname + '/app/public' );
fractal.web.theme( lexiconTheme );

// location of the documentation directory.
fractal.docs.set( 'path', __dirname + '/docs' );
fractal.docs.set( 'default.status', 'draft' );
fractal.docs.set( 'statuses', {
  draft: {
    label: 'Draft',
    description: 'Work in progress.',
    color: '#ff9233'
  },
  ready: {
    label: 'Ready',
    description: 'Ready for referencing.',
    color: '#29cc29'
  },
  changelog: {
    label: 'Changelog',
    description: 'Changes since last release.',
    color: '#1565c0'
  }
});

fractal.components.set( 'default.preview', '@preview' );
// location of the component directory.
fractal.components.set( 'path', __dirname + '/app/modules' );
fractal.components.set( 'default.status', 'wip' );

lexiconTheme.addLoadPath( __dirname + '/theme-overrides/views' );

// This allows to use first open port available in range
op.find({
  startingPort: 3000,
  endingPort: 3050
}, function( err, port ) {
  if ( err ) {
    console.log( err );
    return;
  }

  fractal.web.set( 'server.syncOptions', {
    open: true,
    cors: true,
    browser: 'google chrome',
    ui: {
      port: port
    }
  });
});

module.exports = fractal;
