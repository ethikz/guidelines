import $ from 'jquery';

export const $CONTENT = $( '.content' );
export const $BODY = $( 'body' );
export const ANIM_SPEED_MS = 300;
