/* eslint-disable no-alert */
// Vendor
import Modernizr from 'modernizr';
import $ from 'jquery';

// Global functions
import webfont from 'functions/webfont.js';
import svg4everybody from 'svg4everybody';

// Objects
import Collapsible from 'objects/collapsible/Collapsible.js';
import Grid from 'objects/grid/Grid.js';

// Components
import Accordion from 'components/accordion/Accordion.js';
import BlockAlert from 'components/alerts/block-alert/BlockAlert.js';
import InlineAlert from 'components/alerts/inline-alert/InlineAlert.js';
import ButtonGroup from 'components/button-group/ButtonGroup.js';
import Overlay from 'components/overlay/Overlay.js';
import Modal from 'components/modals/modal/Modal.js';
import Tooltip from 'components/tooltip/tooltip/Tooltip.js';
import Switch from 'components/switch/Switch.js';
import Tabs from 'components/tabs/Tabs.js';


// Init
$( document ).ready( () => {
  svg4everybody();
  webfont();

  if ( $( '.js-lx-overlay' ).length ) {
    Overlay.init();
  }

  if ( $( '.js-lx-modal' ).length ) {
    Modal.init();
  }

  if ( $( '.js-lx-collapsible' ).length ) {
    Collapsible.init();
  }

  if ( $( '.js-lx-block-alert' ).length ) {
    BlockAlert.init();
  }

  if ( $( '.js-lx-inline-alert' ).length ) {
    InlineAlert.init();
  }

  if ( $( '.js-lx-accordion' ).length ) {
    Accordion.init();
  }

  if ( $( '.js-lx-tooltip' ).length ) {
    Tooltip.init();
  }

  if ( $( '.js-lx-button-group' ).length ) {
    ButtonGroup.init();
  }

  if ( $( '.js-lx-grid' ).length && Modernizr.cssgrid === false ) {
    Grid.init();
  }

  if ( $( '.js-lx-switch' ).length ) {
    Switch.init();
  }

  if ( $( '.js-lx-tabs' ).length ) {
    Tabs.init();
  }
});
