# What is this Folder For?
CSS that is applied to the iFrame within each component preview, however is *not* exported or usable for projects that use the Lexicon as a dependency.
