module.exports = {
  'default': 'direction',
  variants: [{
    name: 'direction',
    context: {
      direction: [{
        label: 'row',
        name: 'row',
        'class': 'lx-flex-direction--row'
      }, {
        label: 'column',
        name: 'column',
        'class': 'lx-flex-direction--column'
      }]
    }
  }, {
    name: 'wrap',
    context: {
      direction: [{
        label: 'no-wrap',
        name: 'no-wrap',
        'class': 'lx-flex-wrap--nowrap'
      }, {
        label: 'wrap',
        name: 'wrap',
        'class': 'lx-flex-wrap--wrap'
      }, {
        label: 'wrap-reverse',
        name: 'wrap-reverse',
        'class': 'lx-flex-wrap--wrap-reverse'
      }]
    }
  }, {
    name: 'justify-content',
    context: {
      direction: [{
        label: 'space-between',
        name: 'space-between',
        'class': 'lx-justify-content--space-between'
      }, {
        label: 'space-around',
        name: 'space-around',
        'class': 'lx-justify-content--space-around'
      }, {
        label: 'center',
        name: 'center',
        'class': 'lx-justify-content--center'
      }]
    }
  }, {
    name: 'align-items',
    context: {
      direction: [{
        label: 'flex-start',
        name: 'flex-start',
        'class': 'lx-flex-direction--column lx-align-items--flex-start'
      }, {
        label: 'flex-end',
        name: 'flex-end',
        'class': 'lx-flex-direction--column lx-align-items--flex-end'
      }, {
        label: 'center',
        name: 'center',
        'class': 'lx-flex-direction--column lx-align-items--center'
      }]
    }
  }]
};
