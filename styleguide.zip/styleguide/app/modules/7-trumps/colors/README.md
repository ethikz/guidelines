## Color Palette Utilities
Use utility classes to apply a color palette to an element. For example, `.lx-u-color-palette--primary`.

*Note:* The element in question must use the variables applied via the color palette in order for them to apply. For example, if the `background` CSS property is not defined, it will not inherit the variable from the color palette.

### Usage
On an element:

```html
<div class="hero lx-u-color-palette--tertiary">
</div>
```
