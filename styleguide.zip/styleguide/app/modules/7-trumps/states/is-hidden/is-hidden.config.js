module.exports = {
  description: 'Used to hide elements when they are above and below a predefined breakpoint.'
}
