## Is Hidden
Used to hide elements when they are above and below a predefined breakpoint

### Usage
Add a utility class to hide the element `above` or `below` a predefined set of breakpoints.

The following classes are available:
- `lx-u-hide--below@xs`
- `lx-u-hide--above@xs`
- `lx-u-hide--below@sm`
- `lx-u-hide--above@sm`
- `lx-u-hide--below@md`
- `lx-u-hide--above@md`
- `lx-u-hide--below@lg`
- `lx-u-hide--above@lg`
- `lx-u-hide--below@xl`
- `lx-u-hide--above@xl`
