## Tabs
Tabs are controlled using keyboard focus via the arrow keys, or by clicking on a tab. A variety of aria attributes are used to update users with regards to the current state of the tab component.

### Usage
Tabs are used to store related or UI content in a way that is not presented simultaneously to the user.

Use the `\{{#getJsonContext}}` helper to automatically generate a series of tabs. For example:
```html
\{{#getJsonContext
  '[
    {
      "tabContent": "First tab!",
      "panelContent": "<p>Tab uno!</p>"
    }, {
      "tabContent": "Second tab!",
      "panelContent": "<p>Tab dos!</p>"
    }, {
      "tabContent": "Third tab!",
      "panelContent": "<p>Tab tres!</p>"
    }
  ]'
}}
  \{{> @tabs tabs=this id="example-id" }}
\{{/getJsonContext}}
```

*Note:* - Pass in an `id` to the tabs include directly, and a unique `id` pairing will be generated for each tab and its associated panel.

#### Variants
The `minimal` variant is a less skeumorphic design. Use the parameter `type` and value `minimal` in order to vary the design.

#### Methods
Use `Tabs.activateTab( '#targetId' )` to programmatically activate a tab and its associated panel. To select the appropriate tab panel, note its ID, and pass in that value with the `#` prepended.
