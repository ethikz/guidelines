import $ from 'jquery';

/* eslint-disable no-invalid-this */

const Tabs = ( function() {
  const _private = {
    targetId: null,

    cacheDom: () => {
      _private.$tabs = $( '.js-lx-tabs' );
      _private.$tab = $( '.js-lx-tabs__tab' );
      _private.$panel = $( '.js-lx-tabs__panel' );
    },

    bindEvents: () => {
      _private.$tab.on( 'click', function( e ) {
        e.preventDefault();

        _private.storeThisTarget( $( this ) );
        _private.activateTab( _private.targetId );
      });

      // Detecting right and left arrow key
      _private.$tab.on( 'keyup', function( e ) {
        if ( e.keyCode === 39 ) {
          _private.storeNextTarget( $( this ) );
          _private.activateTab( _private.targetId );
        } else if ( e.keyCode === 37 ) {
          _private.storePrevTarget( $( this ) );
          _private.activateTab( _private.targetId );
        }
      });
    },

    storeThisTarget: ( $thisElem ) => {
      let targetId = $thisElem.attr( 'data-tabtarget' );

      _private.targetId = targetId;
    },

    storeNextTarget: ( $thisElem ) => {
      let targetId = $thisElem.next().attr( 'data-tabtarget' );

      // If the targetId is undefined, that means the user is at the end of the tab list
      if ( targetId === undefined ) {
        let $theseTabs = $thisElem.closest( _private.$tabs );
        let $firstTab = $theseTabs.find( '.js-lx-tabs__tab:first' );

        targetId = $firstTab.attr( 'data-tabtarget' );
      }

      _private.targetId = targetId;
    },

    storePrevTarget: ( $thisElem ) => {
      let targetId = $thisElem.prev().attr( 'data-tabtarget' );

      // If the targetId is undefined, that means the user is at the beginning of the tab list
      if ( targetId === undefined ) {
        let $theseTabs = $thisElem.closest( _private.$tabs );
        let $lastTab = $theseTabs.find( '.js-lx-tabs__tab:last' );

        targetId = $lastTab.attr( 'data-tabtarget' );
      }

      _private.targetId = targetId;
    },

    activateTab: ( targetId ) => {
      let $targetPanel = $( targetId );
      let $siblingPanels = $targetPanel.siblings( _private.$panel );
      let triggerId = $targetPanel.attr( 'data-tabtrigger' );
      let $triggerTab = $( triggerId );
      let $siblingTabs = $triggerTab.siblings( _private.$tab );

      // De-activate all other tabs
      $siblingTabs
        .removeClass( 'is-active' )
        .attr( 'aria-selected', 'false' )
        .attr( 'tabindex', '-1' );

      // Activate the associated trigger tab
      $triggerTab
        .addClass( 'is-active' )
        .attr( 'aria-selected', 'true' )
        .attr( 'tabindex', '0' )
        .focus();

      // De-activate all other panels
      $siblingPanels
        .removeClass( 'is-active' )
        .attr( 'aria-hidden', 'true' );

      // Activate the associated target panel
      $targetPanel
        .addClass( 'is-active' )
        .attr( 'aria-hidden', 'false' );
    },

    init: () => {
      _private.cacheDom();
      _private.bindEvents();
    }
  };

  const _public = {
    init: _private.init,
    activateTab: _private.activateTab
  };

  return _public;
})();

export default Tabs;
