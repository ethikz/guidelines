'use strict';
module.exports = {
  'default': 'default',
  description: 'Tabs are used to present related content or UI, only revealing tab panels when the user takes an action.',
  context: {
    id: 'example-id',
    tabs: [
      {
        tabContent: 'Tab one!',
        panelContent: 'Tab uno!'
      }, {
        tabContent: 'Tab two!',
        panelContent: 'Tab dos!'
      }, {
        tabContent: 'Tab three!',
        panelContent: 'Tab tres!'
      }
    ]
  },
  variants: [{
    label: 'Default',
    name: 'default'
  }, {
    label: 'Minimal',
    name: 'minimal',
    context: {
      type: 'minimal'
    }
  }]
};
