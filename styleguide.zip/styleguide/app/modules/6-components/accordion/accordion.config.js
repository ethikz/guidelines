module.exports = {
  description: 'Used to group and reveal sections of related content',
  preview: '@accordion-preview'
}
