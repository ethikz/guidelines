## Accordion
Accordions are used to group and reveal sections of related content.

### Usage
Accordions are built using a combination of layout blocks, taking advantage of `\{{#extend}}` and `\{{#embed}}` from [Handlebars layouts](https://github.com/shannonmoeller/handlebars-layouts).

- `iconPlacement` determines whether the associated chevron is `right` or `left` within each accordion section
- *NOTE:* each `accordionSection` must have a unique ID

```
\{{#extend 'accordion'
   classes="lx-stack-mg--md"
   id="example-id"
   attr="data-thing=0"
}}
  \{{#content 'mainContent'}}
    \{{#embed 'accordion-section'
       iconPlacement="left"
       id="accordion-group-1"
       buttonContent="Accordion Section 1"
    }}
      \{{#content 'mainContent'}}
        <p>Lorem ipsum dolor sit amet.</p>

        \{{> button
             element="button"
             classes="lx-button--primary"
             mainContent="Continue"
        }}

        \{{> button
             element="button"
             classes="lx-button--secondary"
             mainContent="Cancel"
        }}
      \{{/content}}
    \{{/embed}}

    \{{#embed 'accordion-section'
       iconPlacement="left"
       id="accordion-group-2"
       buttonContent="Accordion Section 2"
    }}
      \{{#content 'mainContent'}}
        <p>Lorem ipsum dolor sit amet.</p>

        \{{> button
             element="button"
             classes="lx-button--primary"
             mainContent="Continue"
        }}

        \{{> button
             element="button"
             classes="lx-button--secondary"
             mainContent="Cancel"
        }}
      \{{/content}}
    \{{/embed}}

    \{{#embed 'accordion-section'
       iconPlacement="left"
       id="accordion-group-3"
       buttonContent="Accordion Section 3"
    }}
      \{{#content 'mainContent'}}
        <p>Lorem ipsum dolor sit amet.</p>

        \{{> button
             element="button"
             classes="lx-button--primary"
             mainContent="Continue"
        }}

        \{{> button
             element="button"
             classes="lx-button--secondary"
             mainContent="Cancel"
        }}
      \{{/content}}
    \{{/embed}}
  \{{/content}}
\{{/extend}}
```
