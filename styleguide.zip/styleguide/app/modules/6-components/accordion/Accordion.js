import $ from 'jquery';
import ANIM_SPEED_MS from 'globals/globals.js';

/* eslint-disable no-invalid-this */

const Accordion = ( function() {
  const _private = {
    cacheDom: () => {
      _private.$accordion = $( '.js-lx-accordion' );
      _private.$section = $( '.js-lx-accordion__section' );
      _private.$trigger = $( '.js-lx-accordion__trigger' );
      _private.$target = $( '.js-lx-accordion__target' );
      _private.$icon = $( '.js-lx-accordion__icon' );
    },

    bindEvents: () => {
      _private.$trigger.on( 'click', function( e ) {
        e.preventDefault();

        _private.toggleTarget( $( this ) );
      });
    },

    preRender: () => {
      _private.$target.slideUp( 0 );
      _private.$trigger.attr( 'aria-expanded', 'false' );
    },

    toggleTarget: ( $thisTrigger ) => {
      let $thisGroup = $thisTrigger.closest( _private.$section );
      let $thisTarget = $thisGroup.find( _private.$target );
      let $thisIcon = $thisGroup.find( _private.$icon );

      // If the trigger isn't expanded, collapse all other sections
      if ( !$thisTrigger.hasClass( 'is-expanded' ) ) {
        _private.collapseAll();
      }

      $thisTrigger
        .toggleClass( 'is-expanded' )
        .attr( 'aria-expanded', ( i, attr ) => {
          return attr == 'true' ? 'false' : 'true';
        });

      $thisTarget.slideToggle( ANIM_SPEED_MS );

      $thisIcon.toggleClass( 'is-rotated' );
    },

    collapseAll: () => {
      _private.$target.slideUp( ANIM_SPEED_MS );

      _private.$trigger
        .removeClass( 'is-expanded' )
        .attr( 'aria-expanded', 'false' );

      _private.$icon.removeClass( 'is-rotated' );
    },

    init: () => {
      _private.cacheDom();
      _private.bindEvents();
      _private.preRender();
    }
  };

  const _public = {
    preRender: _private.preRender,
    toggleTarget: _private.toggleTarget,
    init: _private.init
  };

  return _public;
})();

export default Accordion;
