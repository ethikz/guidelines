import $ from 'jquery';
import ANIM_SPEED_MS from 'globals/globals.js';

/* eslint-disable no-invalid-this */

const ButtonGroup = ( function() {
  const _private = {
    targetId: null,

    cacheDom: () => {
      _private.$group = $( '.js-lx-button-group' );
      _private.$button = _private.$group.find( '.js-lx-button-group__button' );
    },

    bindEvents: () => {
      _private.$button.on( 'click', function( e ) {
        e.preventDefault();

        _private.storeTarget( $( this ) );
        _private.toggleButton( _private.targetId );
      });
    },

    storeTarget: ( $thisElem ) => {
      _private.targetId = $thisElem.attr( 'id' );
    },

    toggleButton: ( targetIdStr ) => {
      let $thisButton = $( '#' + targetIdStr );
      let $siblingButtons = $thisButton.siblings();

      $siblingButtons
        .removeClass( 'is-active' )
        .attr( 'aria-pressed', 'false' );

      $thisButton
        .addClass( 'is-active' )
        .attr( 'aria-pressed', 'true' );
    },

    init: () => {
      _private.cacheDom();
      _private.bindEvents();
    }
  };

  const _public = {
    init: _private.init
  };

  return _public;
})();

export default ButtonGroup;
