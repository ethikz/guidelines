## Button Groups
Button groups are used to group UI in to compact, selectable elements.

### Usage
Use the `\{{#getJsonContext}}` helper to generate a button group. For example:

```
\{{#getJsonContext
    '[
      {
        "mainContent": "15 days"
      }, {
        "mainContent": "30 days"
      }, {
        "mainContent": "60 days"
      }
    ]'
  }}
  \{{> button-group buttons=this id="example-button-group" }}
\{{/getJsonContext}}
```

*Note:* Be sure to pass in an `id` parameter to the button group to dynamically generate a unique ID for each button within.
