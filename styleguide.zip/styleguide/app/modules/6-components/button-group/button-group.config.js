module.exports = {
  description: 'Button groups are used to group UI in to compact, selectable elements.',
  context: {
    id: 'example-button-group',
    classes: 'lx-stack-mg--md',
    buttons: [
      {
        mainContent: '15 days'
      }, {
        mainContent: '30 days'
      }, {
        mainContent: '60 days'
      }, {
        mainContent: '90 days'
      }
    ]
  },
  variants: [{
    name: 'small',
    label: 'Small',
    context: {
      id: 'small-example-button-group',
      type: 'small'
    }
  }, {
    name: 'ghost',
    label: 'Ghost',
    display: {
      background: '#222a31'
    },
    context: {
      id: 'ghost-example-button-group',
      type: 'ghost'
    }
  }]
}
