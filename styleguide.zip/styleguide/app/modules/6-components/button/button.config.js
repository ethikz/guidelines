module.exports = {
  'default': 'primary',
  description: 'Buttons are used to trigger behavior or as a call to action.',
  collated: true,
  context: {
    element: 'a',
    mainContent: 'Click Me!'
  },
  variants: [{
    name: 'primary',
    context: {
      classes: 'lx-button--primary'
    }
  }, {
    name: 'secondary',
    context: {
      classes: 'lx-button--secondary'
    }
  }, {
    name: 'tertiary',
    context: {
      classes: 'lx-button--tertiary'
    }
  }, {
    name: 'ghost',
    context: {
      classes: 'lx-button--ghost'
    },
    display: {
      'background': '#222a31'
    }
  }, {
    name: 'small',
    context: {
      classes: 'lx-button--small'
    }
  }, {
    name: 'large',
    context: {
      classes: 'lx-button--large'
    }
  }, {
    name: 'disabled',
    context: {
      classes: 'lx-button--primary is-disabled'
    }
  }, {
    name: 'left-icon',
    label: 'Left Icon',
    context: {
      leftIcon: true,
      iconSymbol: 'arrow-left-half'
    }
  }, {
    name: 'right-icon',
    label: 'Right Icon',
    context: {
      rightIcon: true,
      iconSymbol: 'arrow-right-half'
    }
  }]
};
