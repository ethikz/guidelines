## Buttons
Buttons are used to trigger behavior or as a call to action.

### Usage
Use buttons using the `\{{> button }}` include.

*Note:* The template does not, by default, use a particular tag. Be sure to pass in `button` for elements that control behavior on a page or submit forms. Be sure to use the `a` element when buttons are calls to action, linking to another page. When using an anchor tag, be sure to include an `href`, otherwise, the template defaults to `javascript:void(0);`.

For example:
```
\{{> button
    element="button"
    classes="lx-button--primary lx-button--large"
    id="my-button"
    mainContent="Click Me"
    afterScreenReaderContent="To Sign Up For Stuff!"
    attr="tabindex=0"
}}
```
