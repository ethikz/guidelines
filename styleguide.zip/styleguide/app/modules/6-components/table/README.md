## Table
Tables are used for storing data.

### Usage
Due to their complexity, tables are not managed with Handlebars component templates, and should be written using HTML on a case-by-case basis.

#### Responsiveness
Within the CSS for this component, there are no media queries. Due to the variable nature of tables between platforms, developers should make use of the `lx-is-hidden` classes to show and hide various rows and columns based on the viewport size.

These classes can be particularly powerful when used in conjunction with the [colgroup](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/colgroup) element, allowing a developer the ability to show and hide columns based on a predetermined set of breakpoints.
