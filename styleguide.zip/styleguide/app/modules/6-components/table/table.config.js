module.exports = {
  description: 'Tables are used to display data',
  variants: [{
    name: 'default'
  }, {
    name: 'inverse',
    context: {
      classes: 'lx-table--inverse'
    },
    display: {
      'background': '#222a31'
    }
  }, {
    name: 'zebra',
    context: {
      classes: 'lx-table--zebra'
    }
  }]
}
