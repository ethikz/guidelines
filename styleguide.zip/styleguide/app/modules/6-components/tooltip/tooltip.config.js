module.exports = {
  description: 'Triggering element to open and close tooltips',
  context: {
    element: 'a',
    id: 'some-trigger',
    target: 'some-tooltip',
    mainContent: 'This is an example tooltip trigger'
  }
}
