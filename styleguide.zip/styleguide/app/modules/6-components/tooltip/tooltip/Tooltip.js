import $ from 'jquery';
import Popper from 'node_modules/popper.js/dist/esm/popper.js';

const Tooltip = ( function() {
  const _private = {
    targetId: null,
    tooltipId: null,

    cacheDom: () => {
      _private.$tooltip = $( '.js-lx-tooltip' );
      _private.$trigger = $( '.js-lx-tooltip__trigger' );
    },

    bindEvents: () => {
      _private.$trigger.on( 'click', ( e ) => {
        e.preventDefault();

        _private.storeTarget( e.target );
        _private.toggleTooltip( _private.targetId );
      });

      $( document ).on( 'click', ( e ) => {
        if ( !$( e.target ).hasClass( 'js-lx-tooltip__trigger' ) ) {
          if ( $( '.js-lx-tooltip.is-visible' ).length > 0 ) {
            if ( $( e.target ).closest( '.js-lx-tooltip' ).length === 0 ) {
              _private.closeAll();
            } else if ( $( e.target ).closest( '.js-lx-tooltip__close' ).length !== 0 ) {
              const triggerId = '#' + $( e.target ).closest( '.js-lx-tooltip' ).attr( 'data-trigger' );

              _private.closeSelf( $( e.target ).closest( '.js-lx-tooltip' ), $( triggerId ) );
            }
          }
        }
      });
    },

    // Initializes the popper.js plugin
    // For documentation, see: https://popper.js.org/popper-documentation.html
    initPopper: () => {
      for ( let trig = 0; trig < _private.$trigger.length; trig++ ) {
        const popper = new Popper( _private.$trigger[trig], _private.$tooltip[trig] );
      }
    },

    storeTarget: ( $thisElem ) => {
      _private.targetId = $thisElem.getAttribute( 'data-target' );
    },

    toggleTooltip: ( targetStr ) => {
      const $thisTarget = $( `#${targetStr}` );
      const thisTriggerId = $thisTarget.attr( 'data-trigger' );
      const $thisTrigger = $( `#${thisTriggerId}` );

      _private.initPopper( $thisTarget );

      $thisTarget
        .toggleClass( 'is-invisible is-visible' )
        .attr( 'aria-hidden', ( i, attr ) => {
          return attr === 'true' ? 'false' : 'true';
        });

      $thisTrigger
        .toggleClass( 'is-pressed' )
        .attr( 'aria-expanded', ( i, attr ) => {
          return attr === 'true' ? 'false' : 'true';
        });
    },

    closeSelf: ( tooltip, tooltipTrigger ) => {
      const $tooltip = $( tooltip );
      const $trigger = $( tooltipTrigger );

      $tooltip
        .removeClass( 'is-visible' )
        .addClass( 'is-invisible' )
        .attr( 'aria-hidden', 'true' );

      $trigger
        .removeClass( 'is-pressed' )
        .attr( 'aria-expanded', 'false' )
        .focus();
    },

    closeAll: () => {
      for ( let tip = 0; tip < _private.$tooltip.length; tip++ ) {
        _private.$tooltip[tip]
          .classList.remove( 'is-visible' )
          .classList.add( 'is-invisible' )
          .setAttribute( 'aria-hidden', 'true' );
      }

      for ( let trig = 0; trig < _private.$trigger.length; trig++ ) {
        _private.$trigger[trig]
          .classList.remove( 'is-pressed' )
          .setAttribute( 'aria-expanded', 'false' );
      }
    },

    init: () => {
      _private.cacheDom();
      _private.bindEvents();
      _private.toggleTooltip();
    }
  };

  const _public = {
    init: _private.init,
    toggleTooltip: _private.toggleTooltip
  };

  return _public;
})();

module.exports = Tooltip;
