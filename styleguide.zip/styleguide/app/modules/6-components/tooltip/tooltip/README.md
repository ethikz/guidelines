## Tooltip
Tooltips are used to define an element on the page, simply.

### Usage
A tooltip must be included with a corresponding trigger component in order to function.

```
\{{> tooltip-trigger
     element="a"
     id="example-trigger"
     target="example-tooltip"
     mainContent="This is an example tooltip trigger"
}}

\{{> tooltip
     id="example-tooltip"
     trigger="example-trigger"
     direction="right"
     mainContent="This is an example tooltip"
}}
```

Note that a unique ID for the trigger and the tooltip must be provided, and associated on the opposing element via the `data-trigger` and `data-target` attributes.

On the tooltip, the `direction` attribute can be supplied, giving the tooltip a default direction, either `top`, `right`, `bottom`, `left`, or `auto`. When not supplied, the tooltip defaults to `auto`.
