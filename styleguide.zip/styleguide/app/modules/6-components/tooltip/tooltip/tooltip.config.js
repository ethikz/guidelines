module.exports = {
  description: 'Tooltips are used to define an element on the page, simply',
  preview: '@tooltip-preview'
}
