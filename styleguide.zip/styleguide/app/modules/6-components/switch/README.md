## Switches
Switches are used as a substitute for a binary checkbox, allowing the user to 'check' and 'uncheck' an element.


### Usage
The developer should label the switch itself via the `ariaLabel` parameter. For references, see this [MDN Article](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/ARIA_Techniques/Using_the_aria-label_attribute).

Content for the checked and unchecked state can be passed in via the `statusContentOff` and `statusContentOn` parameters. By default, the content is 'Off' and 'On'.

By default, switches are off. Include a switch that is on by default by defining `checked` as `true`.

Toggle a switch programmatically using the `.toggleSwitch()` method.

For example:
```
Switch.toggleSwitch( 'targetId' );
```

Include the component on a page like so:
```
\{{> switch
     classes="some-class"
     checked="false"
     id="switch-id"
     ariaLabel="Toggles on and off"
     statusContentOn="Enabled"
     statusContentOff="Disabled"
}}
```
