import $ from 'jquery';

/* eslint-disable no-invalid-this */

const Switch = ( function() {
  const _private = {
    targetId: null,

    // Traverse the dom and find needed elements
    cacheDom: () => {
      _private.$switch = $( '.js-lx-switch' );
      _private.$status = $( '.js-lx-switch__status' );
    },

    // Add event listeners to switch elements on the page
    bindEvents: () => {
      _private.$switch.on( 'click', function( e ) {
        e.preventDefault();
        _private.storeTarget( $( this ) );
        _private.toggleSwitch( _private.targetId );
      });

      _private.$switch.on( 'keydown', function( e ) {
        if ( e.keyCode === 32 ) {
          e.preventDefault();
          _private.storeTarget( $( this ) );
          _private.toggleSwitch( _private.targetId );
        }
      });
    },

    storeTarget: ( $thisElem ) => {
      _private.targetId = $thisElem.attr( 'id' );
    },

    toggleSwitch: ( targetIdStr ) => {
      let $thisElem = $( '#' + targetIdStr );
      let $theseStatuses = $thisElem.siblings( _private.$status );

      // Toggles the `aria-checked` attribute by using a ternary to check the current value
      $thisElem.attr( 'aria-checked', function( i, attr ) {
        return attr == 'on' ? 'off' : 'on';
      });

      // Add/remove 'is-checked' and 'is-unchecked' in order to add animation to the toggling status
      if ( $thisElem.hasClass( 'is-checked' ) ) {
        $thisElem
          .removeClass( 'is-checked' )
          .addClass( 'is-unchecked' );
      } else {
        $thisElem
          .removeClass( 'is-unchecked' )
          .addClass( 'is-checked' );
      }

      $theseStatuses.toggleClass( 'is-active is-inactive' );
    },

    init: () => {
      _private.cacheDom();
      _private.bindEvents();
    }
  };

  const _public = {
    init: _private.init,
    bindEvents: _private.bindEvents,
    toggleSwitch: _private.toggleSwitch
  };

  return _public;
})();

export default Switch;
