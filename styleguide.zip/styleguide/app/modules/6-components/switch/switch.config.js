'use strict';
module.exports = {
  description: 'Switches are used to toggle state on and off',
  collated: true,
  context: {
    id: 'default-switch',
    ariaLabel: 'late night notifications'
  },
  variants: [{
    label: 'Checked',
    name: 'checked',
    context: {
      id: 'checked-switch',
      checked: true,
      statusContentOff: 'No',
      statusContentOn: 'Yes'
    }
  }]
};
