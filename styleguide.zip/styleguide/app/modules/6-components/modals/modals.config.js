module.exports = {
  context: {
    element: 'a',
    target: 'example-modal',
    mainContent: 'Open Modal',
    bottomClose: true
  }
};
