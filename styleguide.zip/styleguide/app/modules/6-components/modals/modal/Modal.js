import $ from 'jquery';
import { $CONTENT, $BODY } from 'globals/globals.js';
import Overlay from 'components/overlay/Overlay.js';

/* eslint-disable no-invalid-this */

const Modal = ( function() {
  const _private = {
    status: 'is-closed',

    // Traverse the DOM and find appropriate elements
    cacheDom: () => {
      _private.$modal = $( '.js-lx-modal' );
      _private.$modalOpen = $( '.js-lx-modal__open' );
      _private.$modalClose = $( '.js-lx-modal__close' );
    },

    // Add event listeners to various elements and keypresses
    bindEvents: () => {
      _private.$modalOpen.on( 'click', function( e ) {
        e.preventDefault();
        // NOTE: see this issue - jQuery $( this ) has issues with `no-invalid-this` rule https://github.com/eslint/eslint/issues/3600
        _private.storeTarget( $( this ) );
        _private.openModal();
      });

      _private.$modalClose.on( 'click', function( e ) {
        e.preventDefault();
        _private.closeModal();
      });

      // escape key closes the modal
      $( document ).on( 'keyup', function( e ) {
        if ( e.keyCode === 27 ) {
          _private.closeModal();
        }
      });
    },

    // Move all modals to the target element, ideally outside of the page's content
    insertHTML: () => {
      let overlayHTML = '<div class="lx-overlay js-lx-overlay is-invisible" role="presentation"></div>';

      _private.$modal.insertBefore( $CONTENT );

      // First check if an overlay is already present...
      if ( $( '.js-lx-overlay' ).length == 0 ) {
        $CONTENT.before( overlayHTML );
        // after inserting overlay dynamically, element needs to be cached and event listener needs to be added
        Overlay.init();
      }
    },

    storeTarget: ( $thisElem ) => {
      let thisTarget = $thisElem.attr( 'data-target' );

      _private.$targetTrigger = $thisElem;
      _private.$targetModal = $( '#' + thisTarget );
      _private.$targetClose = _private.$targetModal.find( _private.$modalClose );
      _private.$targetModalFirstClose = _private.$targetClose.first();
      _private.$targetModalLastClose = _private.$targetClose.last();
    },

    openModal: () => {
      _private.status = 'is-open';

      // show the target modal and make it visible to screen readers
      _private.$targetModal
        .removeClass( 'is-invisible' )
        .addClass( 'is-visible' );

      _private.$targetModal.attr( 'aria-hidden', 'false' );
      $CONTENT.attr( 'aria-hidden', 'true' );
      _private.$targetModalFirstClose.focus();

      Overlay.toggleOverlay();
      _private.toggleScrolling();
      _private.tabTrap();
    },

    closeModal: () => {
      if ( _private.status === 'is-open' ) {
        _private.$targetModal
          .removeClass( 'is-visible' )
          .addClass( 'is-invisible' );

        $CONTENT.attr( 'aria-hidden', 'false' );
        _private.$targetModal.attr( 'aria-hidden', 'true' );
        _private.$targetTrigger.focus();

        Overlay.toggleOverlay();
        _private.toggleScrolling();

        _private.status = 'is-closed';
      }
    },

    tabTrap: () => {
      _private.$targetModalFirstClose.on( 'keydown', function( e ) {
        // if the user presses the tab key in conjunction with the shift key
        if ( e.shiftKey && e.which === 9 ) {
          e.preventDefault();
          _private.$targetModalLastClose.focus();
        }
      });

      _private.$targetModalLastClose.on( 'keydown', function( e ) {
        // if the user presses the tab key and NOT in conjunction with the shift key
        if ( e.which === 9 && !e.shiftKey ) {
          e.preventDefault();
          _private.$targetModalFirstClose.focus();
        }
      });
    },

    toggleScrolling: function() {
      if ( $BODY.css( 'overflow' ) === 'hidden' ) {
        $BODY.css( 'overflow', 'initial' );
      } else {
        $BODY.css( 'overflow', 'hidden' );
      }
    },

    init: function() {
      _private.cacheDom();
      _private.bindEvents();
      _private.insertHTML();
    }
  };

  const _public = {
    init: _private.init,
    storeTarget: _private.storeTarget,
    openModal: _private.openModal,
    closeModal: _private.closeModal
  };

  return _public;
})();

export default Modal;
