module.exports = {
  preview: '@modal-preview'
};
