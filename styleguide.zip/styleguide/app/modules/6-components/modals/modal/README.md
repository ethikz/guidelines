## Modals
Modals are used to display content that is initially hidden from the user.

The class `.js-lx-modal__open` is added to elements that can open a modal. This element's `data-target` attribute with the `id` of the target modal as a value.

The class `.js-lx-modal__close` is added to elements that close the currently open modal.

In order to determine which element is targeted by the open link:
1. For the targeted modal, be sure to add a unique `id`
2. On the modal triggering element, use the `data-target` attribute with the `id` of the target modal as a value

### Usage
Include the modal trigger element. For example:

```
\{{> modal-trigger
     element="a"
     target="example-modal"
     mainContent="Open Sesame!"
}}
```

Then, `\{{#extend}}` the modal itself:

```
\{{#extend '@modal'
   classes="some-class"
   id="example-modal"
   headingElement="h3"
   headingContent="Modal Heading!"
   contentClasses="lx-text-long"
   bottomClose="true"
}}
  \{{#content 'mainContent'}}
    <p>Any content can go here. Including includes!</p>
  \{{/content}}
\{{/extend}}
```

#### Options
- Set `bottomClose` to `true` if the close button in the bottom of the modal is required

### Accessibility
This particular modal implementation is accessible due to additional JavaScript. Of note:
1. When the modal opens, the content of the page is hidden from screen readers and the first clickable element receives keyboard focus
2. If the user uses the `tab` or `shift + tab` to navigate via keyboard, the user cannot move outside of the opened modal
3. When the modal closes, the content of the page is once again visible to screen readers and the element that triggered the element to open receives keyboard focus
4. The modal can be closed by using the `esc` key
