module.exports = {
  description: 'Panels are used to contain content or user interface. They can optionally be collapsible',
  preview: '@panel-preview'
}
