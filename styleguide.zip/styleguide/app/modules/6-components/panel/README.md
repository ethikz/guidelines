## Panel
Panels are simple container elements that can be used to display related information or UI.

### Usage
As containers, panels utilize Handlebars `\{{#extend}` blocks.

- when `footer` is `true` the panel has a footer and can contain optional content
- when `collapsible` is `true`, the panel collapses and expands based on user interaction

```
\{{#extend 'panel'
   collapsible='true'
   triggerId='collapsible-panel'
   headerContent='Collapsible Panel'
}}
  \{{#content 'mainContent'}}
    <div class="lx-panel__content lx-text-long">
      <h3>Lorem ipsum dolor</h3>

      <p>Duis et neque aliquam, dictum lacus at, mattis augue.</p>

      <p>Aenean diam nulla, ultricies nec pharetra vitae</p>

      \{{> button
           element="button"
           classes="lx-button--primary"
           mainContent="Continue"
      }}

      \{{> button
           element="button"
           classes="lx-button--secondary"
           mainContent="Cancel"
      }}
    </div>
  \{{/content}}

  \{{#content 'footerContent'}}
    <p>Here is some footer content.</p>
  \{{/content}}
\{{/extend}}
```
