## Close Button
Close buttons are used to dismiss components or sections of a page. In and of themselves, they have basic styling with no functionality. Developers can use this component within other components, and with JavaScript, use them to make user interface dismissable.
