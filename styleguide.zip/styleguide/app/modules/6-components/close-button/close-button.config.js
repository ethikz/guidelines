module.exports = {
  'default': 'default',
  description: 'Generic close button design for re-use within dismissable components.'
};
