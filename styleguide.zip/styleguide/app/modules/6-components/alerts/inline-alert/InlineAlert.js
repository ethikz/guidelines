import $ from 'jquery';
import ANIM_SPEED_MS from 'globals/globals.js';

const InlineAlert = ( function() {
  const _private = {
    showTarget: ( targetStr ) => {
      let $thisTarget = $( '#' + targetStr );

      $thisTarget
        .removeClass( 'is-hidden' )
        .addClass( 'is-visible' )
        .slideDown( ANIM_SPEED_MS );

      $thisTarget.attr( 'aria-hidden', 'false' );
    },

    hideTarget: ( targetStr ) => {
      let $thisTarget = $( '#' + targetStr );

      $thisTarget
        .removeClass( 'is-visible' )
        .addClass( 'is-hidden' )
        .slideUp( ANIM_SPEED_MS );

      $thisTarget.attr( 'aria-hidden', 'true' );
    }
  };

  const _public = {
    show: _private.showTarget,
    hide: _private.hideTarget
  };

  return _public;
})();

export default InlineAlert;
