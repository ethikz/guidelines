module.exports = {
  'default': 'attention',
  description: 'Alerts provide feedback to the user, either when a system failure or inappropriate user action occur.',
  variants: [{
    label: 'Attention',
    name: 'attention',
    context: {
      type: 'attention',
      classes: 'lx-u-display--block',
      id: 'some-id',
      attr: 'attribute="value"',
      mainContent: 'This is an attention message.'
    }
  }, {
    label: 'Error',
    name: 'error',
    context: {
      type: 'error',
      classes: 'lx-u-display--block',
      id: 'some-id',
      attr: 'attribute="value"',
      mainContent: 'This is an error message.'
    }
  }, {
    label: 'Success',
    name: 'auccess',
    context: {
      type: 'success',
      classes: 'lx-u-display--block',
      id: 'some-id',
      attr: 'attribute="value"',
      mainContent: 'This is a success message.'
    }
  }, {
    label: 'Info',
    name: 'info',
    context: {
      type: 'info',
      classes: 'lx-u-display--block',
      id: 'some-id',
      attr: 'attribute="value"',
      mainContent: 'This is an info message.'
    }
  }, {
    label: 'Announcement',
    name: 'announcement',
    context: {
      type: 'announcement',
      classes: 'lx-u-display--block',
      id: 'some-id',
      attr: 'attribute="value"',
      mainContent: 'This is an announcement message.'
    }
  }, {
    label: 'System',
    name: 'system',
    context: {
      type: 'system',
      classes: 'lx-u-display--block',
      id: 'some-id',
      attr: 'attribute="value"',
      mainContent: 'This is a system message.'
    }
  }]
};
