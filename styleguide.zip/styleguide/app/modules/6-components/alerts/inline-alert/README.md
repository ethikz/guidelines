## Inline Alerts
Inline notifications are used to inform the user of status changes related to smaller, more micro-level components of a page. For example, used as an inline error message next to a form control.

### Usage
Include an inline alert using Handlebars:

```
\{{> inline-alert
     type="error"
     classes="some-class"
     id="some-id"
     attr="data-thing=0"
     mainContent="This is an attention message."
}}
```

### Applying an ID
*All* inline notifications should have a unique ID - when used in conjunction with the `aria-describedby` attribute, an ID is critical to ensure the component behaves in an accessible manner.

For example, an `<input>` that is in an error state and has an associated inline notification, the `<input>` should have `aria-describedby='{{ id-of-the-inline-alert }}'`.

---

### JavaScript
The `InlineAlert` object has methods available for use by developers.

`InlineAlert.show()` method is used to show inline notification messages.

`InlineAlert.hide()` method is used to hide inline notification messages.
