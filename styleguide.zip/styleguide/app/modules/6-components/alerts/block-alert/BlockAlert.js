import $ from 'jquery';
import ANIM_SPEED_MS from 'globals/globals.js';

/* eslint-disable no-invalid-this */

const BlockAlert = ( function() {
  const _private = {
    targetId: null,

    cacheDom: () => {
      _private.$alert = $( '.js-lx-block-alert' );
      _private.$alertCloseBtn = $( '.js-lx-block-alert__close' );
    },

    bindEvents: () => {
      _private.$alertCloseBtn.on( 'click', function( e ) {
        e.preventDefault();
        // NOTE: see this issue - jQuery $( this ) has issues with `no-invalid-this` rule https://github.com/eslint/eslint/issues/3600
        _private.storeTarget( $( this ) );
        _private.closeTarget( _private.targetId );
      });
    },

    storeTarget: ( $thisElem ) => {
      let $thisParent = $thisElem.closest( _private.$alert );

      _private.targetId = $thisParent.attr( 'id' );
    },

    openTarget: ( targetStr ) => {
      let $thisTarget = $( '#' + targetStr );
      let $thisParent = $thisTarget.closest( _private.$alert );
      let $thisCloseBtn = $thisTarget.find( _private.$alertCloseBtn );

      $thisParent
        .removeClass( 'is-invisible' )
        .addClass( 'is-visible' )
        .slideDown( ANIM_SPEED_MS );

      $thisCloseBtn.focus();
      $thisParent.attr( 'aria-hidden', 'false' );
    },

    closeTarget: ( targetStr ) => {
      let $thisTarget = $( '#' + targetStr );
      let $thisParent = $thisTarget.closest( _private.$alert );

      $thisParent
        .removeClass( 'is-visible' )
        .addClass( 'is-invisible' )
        .slideUp( ANIM_SPEED_MS );

      $thisParent.attr( 'aria-hidden', 'true' );
    },

    init: () => {
      _private.cacheDom();
      _private.bindEvents();
    }
  };

  const _public = {
    open: _private.openTarget,
    close: _private.closeTarget,
    init: _private.init
  };

  return _public;
})();

export default BlockAlert;
