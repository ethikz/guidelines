module.exports = {
  'default': 'attention',
  collated: false,
  description: 'Alerts provide feedback to the user, either when a system failure or inappropriate user action occur.',
  variants: [{
    label: 'Attention',
    name: 'attention',
    context: {
      type: 'attention',
      classes: 'some-class',
      id: 'some-id',
      attr: '',
      headingTag: 'h4',
      headingContent: 'Attention Alert',
      paragraphContent: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id cursus sem, in gravida mauris.',
      linkHref: 'http://bbt.com',
      linkContent: 'Go to BBT.com for more information',
      linkAttr: ''
    }
  }, {
    label: 'Error',
    name: 'error',
    context: {
      type: 'error',
      classes: 'some-class',
      id: 'some-id',
      attr: '',
      headingTag: 'h4',
      headingContent: 'Error Alert',
      paragraphContent: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id cursus sem, in gravida mauris.',
      linkHref: 'http://bbt.com',
      linkContent: 'Go to BBT.com for more information',
      linkAttr: ''
    }
  }, {
    label: 'Success',
    name: 'success',
    context: {
      type: 'success',
      classes: 'some-class',
      id: 'some-id',
      attr: '',
      headingTag: 'h4',
      headingContent: 'Success Alert',
      paragraphContent: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id cursus sem, in gravida mauris.',
      linkHref: 'http://bbt.com',
      linkContent: 'Go to BBT.com for more information',
      linkAttr: ''
    }
  }, {
    label: 'Info',
    name: 'info',
    context: {
      type: 'info',
      classes: 'some-class',
      id: 'some-id',
      attr: '',
      headingTag: 'h4',
      headingContent: 'Info Alert',
      paragraphContent: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id cursus sem, in gravida mauris.',
      linkHref: 'http://bbt.com',
      linkContent: 'Go to BBT.com for more information',
      linkAttr: ''
    }
  }, {
    label: 'Announcement',
    name: 'announcement',
    context: {
      type: 'announcement',
      classes: 'some-class',
      id: 'some-id',
      attr: '',
      headingTag: 'h4',
      headingContent: 'Announcement Alert',
      paragraphContent: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id cursus sem, in gravida mauris.',
      linkHref: 'http://bbt.com',
      linkContent: 'Go to BBT.com for more information',
      linkAttr: ''
    }
  }, {
    label: 'System',
    name: 'system',
    context: {
      type: 'system',
      classes: 'some-class',
      id: 'some-id',
      attr: '',
      headingTag: 'h4',
      headingContent: 'System Alert',
      paragraphContent: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id cursus sem, in gravida mauris.',
      linkHref: 'http://bbt.com',
      linkContent: 'Go to BBT.com for more information',
      linkAttr: ''
    }
  }, {
    label: 'Dismissable',
    name: 'dismissable',
    context: {
      type: 'info',
      classes: 'is-visible',
      id: 'some-id',
      attr: '',
      headingTag: 'h4',
      headingContent: 'Dismissable Alert',
      paragraphContent: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id cursus sem, in gravida mauris.',
      linkHref: 'http://bbt.com',
      linkContent: 'Go to BBT.com for more information',
      linkAttr: '',
      dismissable: 'yes'
    }
  }, {
    label: 'Inset',
    name: 'inset',
    context: {
      type: 'error',
      classes: 'lx-block-alert--inset',
      id: 'some-id',
      attr: '',
      headingTag: 'h4',
      headingContent: 'Inset Alert',
      paragraphContent: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id cursus sem, in gravida mauris.'
    }
  }, {
    label: 'No Icon',
    name: 'no-icon',
    context: {
      type: 'attention',
      id: 'some-id',
      attr: '',
      headingTag: 'h4',
      headingContent: 'No Icon Alert',
      paragraphContent: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus id cursus sem, in gravida mauris.',
      iconDisabled: 'true'
    }
  }]
};
