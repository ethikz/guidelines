module.exports = {
  title: 'Alerts'
}
