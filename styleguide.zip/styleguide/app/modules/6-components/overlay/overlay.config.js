module.exports = {
  description: 'Overlay that displays over most of the content of a page, typically only showing a small component on top',
  preview: '@overlay-preview'
}
