## Overlay
The overlay is used in conjunction with other elements, typically lightboxes or modals, to visually obscure the content of a page or section.
