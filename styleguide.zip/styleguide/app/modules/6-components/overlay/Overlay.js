import $ from 'jquery';

/* eslint-disable no-invalid-this */

const Overlay = ( function() {
  const _private = {
    cacheDom: () => {
      _private.$overlay = $( '.js-lx-overlay' );
      _private.$overlayTrigger = $( '.js-lx-overlay__trigger' );
    },

    bindEvents: () => {
      _private.$overlayTrigger.on( 'click', function( e ) {
        e.preventDefault();
        _private.toggleOverlay();
      });
    },

    toggleOverlay: () => {
      if ( _private.$overlay.hasClass( 'is-visible' ) ) {
        _private.$overlay
          .removeClass( 'is-visible' )
          .addClass( 'is-invisible' );
      } else {
        _private.$overlay
          .removeClass( 'is-invisible' )
          .addClass( 'is-visible' );
      }
    },

    init: () => {
      _private.cacheDom();
      _private.bindEvents();
    }
  };

  const _public = {
    init: _private.init,
    toggleOverlay: _private.toggleOverlay
  };

  return _public;
})();

export default Overlay;
