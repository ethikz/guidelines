## List Group
List groups are a style for unordered lists, used to draw emphasis.

### Usage
Include the component using the [getJsonContext Handlebars helper](https://stackoverflow.com/questions/30372693/passing-an-array-of-objects-to-a-partial-handlebars-js).

For example:
```
\{{#getJsonContext
  '[
      {
        "link": true,
        "href": "http://bbt.com",
        "classes": "test",
        "mainContent": "Open a Checking Account"
      }, {
        "classes": "test-again",
        "mainContent": "Lorem ipsum dolor sit amet consecutir"
      }, {
        "classes": "testing",
        "mainContent": "Contrary to popular belief, Lorem Ipsum is not simply random text."
      }
    ]'
}}
  \{{> list-group items=this }}
\{{/getJsonContext}}
```

The component template loops through the list of objects, generating a new list item for each object.

*Note*: If you want the link to render as a link then you need to have `"link": true`, then the list item contains a link.
