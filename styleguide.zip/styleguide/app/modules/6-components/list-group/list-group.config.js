module.exports = {
  description: 'List groups are a style for unordered list, used to draw emphasis. Items can be links.',
  context: {
    items: [{
      link: true,
      href: 'http://bbt.com',
      classes: 'test',
      mainContent: 'Open a Checking Account',
      attr: 'attribute="attribute"'
    }, {
      classes: 'test-again',
      mainContent: 'Lorem ipsum dolor sit amet consecutir'
    }, {
      classes: '',
      mainContent: 'Contrary to popular belief, Lorem Ipsum is not simply random text. '
    }]
  },
  variants: [{
    label: 'Default',
    name: 'default'
  }, {
    label: 'Inset',
    name: 'inset',
    context: {
      classes: 'lx-list-group--inset'
    }
  }]
};
