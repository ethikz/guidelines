## Collapsible
Collapsible elements can be opened or closed, typically used to hide or show content that does not always need to be immediately available to the user.

### Usage
1. To a wrapping element, add the class `js-lx-collapsible`
2. To a trigger element within the wrapping element, add the class `js-lx-collapsible__trigger` - *Note:* if this is not a `<button>` element, be sure to add `role="button"`. If this is an `<a>` element, be sure to additionally add `href="javascript:void(0);"` and `tabindex="0"`
3. To a target element within the wrapping element, add the class `js-lx-collapsible__target`
4. If a chevron icon is present, it needs the class `js-lx-collapsible__icon`
5. The `js-lx-collapsible__trigger` must have an `id`
6. The `js-lx-collapsible__target` must have an `aria-labelledby` attribute with the value of the `js-lx-collapsible__trigger` ID
7. The `js-lx-collapsible__trigger` must have `role="region"`

### Complexity
Though this behavior appears complex, it is largely intended for use within Lexicon components that the behavior can be simplified via templating.

For example, the `collapsible` panel variant uses this mixture of classes and behavior and is thus tied to that template. For a typical developer to use this component, they will not need to be aware of the aforementioned complexity.
