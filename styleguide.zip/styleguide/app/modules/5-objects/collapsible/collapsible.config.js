module.exports = {
  description: 'Collapsible behavior that is applied generally to components',
  context: {
    triggerId: 'example-trigger',
    triggerContent: 'Example trigger',
    targetContent: 'Example target content'
  }
}
