import $ from 'jquery';
import ANIM_SPEED_MS from 'globals/globals.js';

/* eslint-disable no-invalid-this */

const Collapsible = ( function() {
  const _private = {
    cacheDom: () => {
      _private.$collapsible = $( '.js-lx-collapsible' );
      _private.$trigger = $( '.js-lx-collapsible__trigger' );
      _private.$target = $( '.js-lx-collapsible__target' );
      _private.$icon = $( '.js-lx-collapsible__icon' );
    },

    bindEvents: () => {
      _private.$trigger.on( 'click', function( e ) {
        e.preventDefault();

        _private.toggleTarget( $( this ) );
      });
    },

    preRender: () => {
      _private.$trigger.attr( 'aria-expanded', 'false' );
      _private.$target.slideUp( 0 );
    },

    toggleTarget: ( $thisTrigger ) => {
      let $thisParent = $thisTrigger.closest( _private.$collapsible );
      let $thisTarget = $thisParent.find( _private.$target );
      let $thisIcon = $thisParent.find( _private.$icon );

      $thisTrigger
        .toggleClass( 'is-expanded' )
        .attr( 'aria-expanded', ( i, attr ) => {
          return attr == 'true' ? 'false' : 'true';
        });

      $thisTarget.slideToggle( ANIM_SPEED_MS );

      $thisIcon.toggleClass( 'is-rotated' );
    },

    init: () => {
      _private.cacheDom();
      _private.bindEvents();
      _private.preRender();
    }
  };

  const _public = {
    preRender: _private.preRender,
    toggleTarget: _private.toggleTarget,
    init: _private.init
  };

  return _public;
})();

export default Collapsible;
