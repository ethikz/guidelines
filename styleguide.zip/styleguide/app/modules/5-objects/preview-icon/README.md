## Icons
The icon system makes use of the inline `<svg>` element via a cache-able, SVG spritesheet.

### Usage
```
\{{> icon
    symbol="pig"
    classes="insert-classes-here"
    title="Savings Account"
    attr="role=presentation"
}}
```

Will output:

```
<svg class="lx-icon lx-icon--pig u-mg-y--sm" role="presentation">
  <title>Savings Account</title>
  <use xlink:href="../icons/svg/symbols.svg#pig" />
</svg>
```

### Accessibility
Icons should make use of the `<title>` attribute when used within a component. When using the Handlebars partial, simply pass in the title via the `title` attribute.
