var fs = require( 'fs' ),
    EventEmitter = require( 'events' ).EventEmitter,
    filesEE = new EventEmitter(),
    icon = [];

fs.readdir( __dirname + '/../_icon/svgs/', function( err, files ) {
  if ( err ) {
    throw err;
  }

  files.forEach( function( file ) {
    icon.push({
      symbol: file.slice( 0, -4 )
    });
  });

  // trigger files_ready event
  filesEE.emit( 'files_ready' );

  return icon;
});

module.exports = {
  name: 'preview-icon',
  label: 'Icon',
  context: {
    icons: icon
  }
};
