import $ from 'jquery';

const Grid = ( function() {
  const _private = {
    init: function() {
      _private.cacheDom();
      _private.wrapElements( _private.$grid );
    },

    cacheDom: function() {
      _private.$grid = $( '.js-lx-grid' );
    },

    wrapElements: function( $parentElement ) {
      let $childElements = $parentElement.children();

      $childElements.wrap( "<div class='lx-grid__cell'></div>" );
    }
  };

  const _public = {
    init: _private.init
  };

  return _public;
})();

export default Grid;
