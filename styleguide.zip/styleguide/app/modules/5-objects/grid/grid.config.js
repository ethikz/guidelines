module.exports = {
  description: 'System used to rapidly build page or section layouts'
};
