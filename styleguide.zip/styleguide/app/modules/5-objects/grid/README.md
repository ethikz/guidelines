## Grid
The grid system makes use of [CSS Grid](https://developer.mozilla.org/en-US/docs/Web/CSS/grid) to create consistent, re-usable grids.

### Usage
A variety of classes can be added to a parent element to apply a layout to its immediate children.

- Add `.lx-grid` to all parent grid elements
- By default, the grid has no gutters. To add both vertical and horizontal gutters, add the modifier class `.lx-grid--gutters`
- For column gutters only, add `.lx-grid--column-gutters`
- For row gutters only, add `.lx-grid--row-gutters`
- For a persistent two column grid, add the modifier class `.lx-grid--2-columns`
- For a two column grid that is only present above a certain breakpoint, use `.lx-grid--2-columns-md-up`
- For uneven columns, use the `-offset` modifier classes. For example, use `.lx-grid--1-4-offset` for a 1/4 column followed by a column that fills the remaining space

### Customization
Individual projects can increase or decrease the number of supported grids by overriding the value of the `$max-supported-columns` variable (by default set to `8`);

Additionally, individual projects can modify the gutter width by overriding the `$base-gutter` variable.

---

## CSS Grid Fallback for Unsupported Browsers
CSS Grid is a relatively new CSS layout technique that is largely supported on modern browsers.

As a fallback, the grid takes advantage of [Modernizr](https://modernizr.com/) to detect whether a browser supports CSS grid, and if it does not, will use a flexbox-based grid system as a fallback.

*Note:* Due to IE related [flexbox bugs](https://github.com/philipwalton/flexbugs), JavaScript is required to dynamically wrap each immediate grid child in an empty `<div>` with a class of `lx-grid__cell`.

**Warning:** This fallback only effects Lexicon classes, and as a result, any custom CSS grid implementation within a project will need its own fallback. Wrap any elements within the Modernizr class `no-cssgrid` to apply a fallback of your own.
