module.exports = {
  description: 'Color palettes used by default in the Lexicon. These can be overridden on a project-by-project basis.',
  'default': 'primary',
  collated: true,
  variants: [{
    name: 'primary',
    context: {
      background: '#fff',
      foreground: '#12161a',
      middleground: '#ccc',
      accent: '#1565c0',
      highlight: '#903'
    }
  }, {
    name: 'secondary',
    context: {
      background: '#f7f7f7',
      foreground: '#12161a',
      middleground: '#8b8b8b',
      accent: '#217ee7',
      highlight: '#ffc107'
    }
  }, {
    name: 'tertiary',
    context: {
      background: '#222a31',
      foreground: '#fff',
      middleground: '#394652',
      accent: '#217ee7',
      highlight: '#ffc107'
    }
  }, {
    name: 'attention',
    context: {
      background: '#fefbeb',
      foreground: '#58480d',
      middleground: '#ffdf8c'
    }
  }, {
    name: 'error',
    context: {
      background: '#feefeb',
      foreground: '#d0181b',
      middleground: '#fab2b2'
    }
  }, {
    name: 'success',
    context: {
      background: '#ddf2da',
      foreground: '#316104',
      middleground: '#b3c5af'
    }
  }, {
    name: 'system',
    context: {
      background: '#e4e4e4',
      foreground: '#4f4c4c',
      middleground: '#a7a7a7'
    }
  }, {
    name: 'announcement',
    context: {
      background: '#e0eff3',
      foreground: '#283c41',
      middleground: '#90dced'
    }
  }, {
    name: 'info',
    context: {
      background: '#f3f7ff',
      foreground: '#3e4c5d',
      middleground: '#888f97'
    }
  }]
};
