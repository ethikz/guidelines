## Color Palettes
Color palettes used by default in the Lexicon. These can be overridden on a project-by-project basis.

### Usage
Color palettes can be referenced using CSS, and can be modified by redefining the `$color-maps` Sass map on a project-by-project basis.

```
.tile {
  background: get-color(primary, background); /* sets the background to the primary background color */
  color: get-color(primary, foreground); /* sets the color to the primary foreground color */
}
```

There are several color palettes available with color definitions that fit a traditional color scheme.

- `primary`
- `secondary`
- `tertiary`
- `attention`
- `error`
- `success`
- `system`
- `announcement`
- `info`

Each color palette has the following series of values. *Note:* the status color palettes do not have unique `accent` and `highlight` colors:

- `foreground`
- `background`
- `middleground`
- `middleground-plus-background`
- `middleground-plus-foreground`
- `accent`
- `highlight`

Use the `get-color()` function to retrieve a color from a color palette. For example, to retrieve the `tertiary` palette's `background` color:

```
.button {
  background: get-color(tertiary, background); /* sets the background to the tertiary background color */
}
```
