module.exports = {
  'default': 'inset',
  title: 'Spacing Models',
  label: 'Spacing Models',
  description: 'Units of spacing for use within and between components',
  status: 'ready',
  variants: [{
    name: 'inset',
    context: {
      variables: [{
        model: 'inset',
        value: 'xs'
      }, {
        model: 'inset',
        value: 'sm'
      }, {
        model: 'inset',
        value: 'md'
      }, {
        model: 'inset',
        value: 'lg'
      }, {
        model: 'inset',
        value: 'xl'
      }]
    }
  }, {
    name: 'inset-squish',
    context: {
      variables: [{
        model: 'inset-squish',
        value: 'sm'
      }, {
        model: 'inset-squish',
        value: 'md'
      }, {
        model: 'inset-squish',
        value: 'lg'
      }, {
        model: 'inset-squish',
        value: 'xl'
      }]
    }
  }, {
    name: 'inset-stretch',
    context: {
      variables: [{
        model: 'inset-stretch',
        value: 'sm'
      }, {
        model: 'inset-stretch',
        value: 'md'
      }, {
        model: 'inset-stretch',
        value: 'lg'
      }]
    }
  }, {
    name: 'stack',
    context: {
      variables: [{
        model: 'stack',
        value: 'xs'
      }, {
        model: 'stack',
        value: 'sm'
      }, {
        model: 'stack',
        value: 'md'
      }, {
        model: 'stack',
        value: 'lg'
      }, {
        model: 'stack',
        value: 'xl'
      }]
    }
  }, {
    name: 'inline',
    context: {
      variables: [{
        model: 'inline',
        value: 'xs'
      }, {
        model: 'inline',
        value: 'sm'
      }, {
        model: 'inline',
        value: 'md'
      }, {
        model: 'inline',
        value: 'lg'
      }, {
        model: 'inline',
        value: 'xl'
      }]
    }
  }]
};
