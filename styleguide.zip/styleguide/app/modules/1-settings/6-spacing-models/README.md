## Spacing Models
Spacing models are inspired by an article by Nathan Curtis, [Space in Design Systems](https://medium.com/eightshapes-llc/space-in-design-systems-188bcbae0d62).

Making use of pre-existing, generic spacing variables, the Lexicon spacing system makes use of predictable concepts in order to allow for predictable, interlocking components that appear visually balanced and consistent.

*Note*: These spacing models are not constrained to use within `padding` or `margin` properties, rather, it is up to the developer to determine their appropriate use within the box model.

### Models
#### Inset
*Definition:*
Even spacing within the interior of a component - the values are the same on all sides of the element

#### Inset Squish
*Definition:*
Spacing is wider on the sides than on the top and bottom

#### Inset Stretch
*Definition:*
Spacing is wider on the top and bottom than on the sides

#### Stack
*Definition:*
Vertical spacing, used for stacking elements - only applies to the bottom of an element

#### Inline
*Definition:*
Horizontal spacing for elements next to one another - only applies to the right side of an element

---

### Usage
In CSS, make use of the `get-spacing()` function:

```css
.hero {
  padding: get-spacing(inset, xl);
}
```

*Note:* This function produces a long-form declaration, therefore, `padding-right: get-spacing(inline, xs)` will not render.
