module.exports = {
  title: 'Breakpoints',
  label: 'Breakpoints',
  status: 'ready',
  hidden: true,
  context: {
    variables: [{
      name: '$breakpoint--xs',
      value: '380px'
    }, {
      name: '$breakpoint--sm',
      value: '481px'
    }, {
      name: '$breakpoint--md',
      value: '768px'
    }, {
      name: '$breakpoint--lg',
      value: '960px'
    }, {
      name: '$breakpoint--xl',
      value: '1041px'
    }]
  }
};
