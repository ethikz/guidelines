module.exports = {
  status: 'ready'
};
