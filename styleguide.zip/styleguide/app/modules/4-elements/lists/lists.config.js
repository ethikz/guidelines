module.exports = {
  title: 'Lists',
  label: 'Lists',
  status: 'ready',
  'default': 'unordered',
  variants: [{
    name: 'unordered',
    label: 'Unordered',
    context: {
      element: 'ul'
    }
  }, {
    name: 'ordered',
    label: 'Ordered',
    context: {
      element: 'ol'
    }
  }]
}
