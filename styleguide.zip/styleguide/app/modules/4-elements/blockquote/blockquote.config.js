module.exports = {
  context: {
    name: 'blockquote',
    mainContent: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis id ligula arcu.'
  }
};
