---
title: Front End Checklist
---

This is to be used and referenced before sending any code to Code Review and QA

- [Common Stuff](#common-stuff)
- [Accessibility](#accessibility)
- [Graphics](#graphics)
- [SEO and Social](#seo-and-social)
- [Validation and Performance](#validation-and-performance)
- [Build Systems](#build-systems)

---

## Common stuff
- Check responsive design for typical resolutions (320, 480, 1024, 1600, 2k, 4k)
- [Viewport](https://developer.mozilla.org/en-US/docs/Mozilla/Mobile/Viewport_meta_tag) meta tag X-UA-Compatible meta tag [<sup>1</sup>](#-1-x-ua-compatible)
- Correct headers (i.e charset = utf8)?
- Pages work without JavaScript errors?
- Reasonable pixel precision achieved?
- Support browsers that are current and 'two back' from current. Reference [CanIUse](http://caniuse.com) for current releases
- Desktop Browsers
  - IE10/11
  - Chrome
  - Firefox
  - Safari
- Mobile Browsers
  - Support for iOS (Safari and Chrome)
  - Chrome for Android
- Individual product owners *do* have the authority to support browsers beyond the aforementioned, though must recognize the tradeoffs that support entails
- Pages follow HTML, CSS, JavaScript coding standards?
- Excessively specific CSS selectors and improper use of **!important** rule avoided?
- Any CSS hacks?
- Unnecessary classes or ids?
- Is the code well structured?
- Do any aspects of the layout break if font size is increased/decreased?

## Accessibility
- Use accessible forms, tables?
- Are all links descriptive (for blind users)?
- Are correct `alt` attributes for images provided?

## Graphics
- Favicon 16x16, 32x32 [<sup>2</sup>](#-2-favicon)
- Apple icons [<sup>3</sup>](#-3-apple-icons)
- Android icons [<sup>4</sup>](#-4-android-icons)
- Support retina displays?
- Sprites and icon fonts?

## SEO and Social
- Common meta tags [<sup>5</sup>](#-5-common-meta-tags)
- All [absolute paths](http://www.seoclarity.net/difference-relative-absolute-url-15325/) without protocol?

## Validation and Performance
- [Google PageSpeed](https://developers.google.com/speed/pagespeed)
- [HTML Validation](http://validator.w3.org/)
- [CSS Validation](http://jigsaw.w3.org/css-validator)
- [Link checker](http://validator.w3.org/checklink)
- [Web Accessibility Checker (for live site)](http://wave.webaim.org/)
- [Web Accessibility Checker (for file upload)](https://achecker.ca/checker/index.php)

## Build Systems
- Code style (jshint, eslint) for JavaScript, (scss lint) for SCSS
- Are stylesheets/javascripts merged and minified?
- Minify all images
- Don't save builds/compiled files in Git

---

###### [1] X-UA-Compatible

```
<meta http-equiv="X-UA-Compatible" content="IE=edge">
```
###### [2] Favicon

```
<link rel="shortcut icon" type="image/x-icon" href="path/to/icon.ico">
```
###### [3] Apple icons

```
<link rel="apple-touch-icon" href="57x57.png">
<link rel="apple-touch-icon" href="72x72.png" sizes="72x72">
<link rel="apple-touch-icon" href="114x114.png" sizes="114x114">
<link rel="apple-touch-startup-image" href="57x57.png">
```
###### [4] Android icons

```
<link rel="icon" sizes="192x192" href="androidx2.png">
<link rel="icon" sizes="128x128" href="android.png">
```
###### [5] Common meta tags

```
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="viewport" content="width=device-width, initial-scale=1">
```
