---
title: Hierarchy Definitions
status: ready
---

The Lexicon is structured, from a CSS perspective, using [Inverted Triangle CSS](https://www.xfive.co/blog/itcss-scalable-maintainable-css-architecture/). This approach helps organize CSS in a predictable, scaleable manner, however, can be confusing for non-developers.

## For Non-Developers
The following categories are relevant for non-developer consideration:

### Objects
Objects are building blocks typically used to contain other elements, that do not have a very specific context. For example, a container class, icons, or a grid system.

---

### Components
Components are the basic user-interface building blocks that form the backbone of the Lexicon. For example, a button or modal component.

---

### Modules
Modules are more complex groups of user-interface that are composed of components. For example, a login form. These are *global* and are intended to for use across a wide variety of platforms.

---

### Patterns
Patterns are modules that exist only within a particular platform or very small subset of platforms. The Lexicon will not have example patterns, rather, these will be managed on the platform level.
