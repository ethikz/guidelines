---
title: Frequently Asked Questions
label: FAQ's
---

### What are the project dependencies I need to know about?
The Digital Lexicon makes use of node modules which are managed via the [Gulp](http://gulpjs.com) task runner. First, follow installation directions provided on their [getting started guide](https://github.com/gulpjs/gulp/blob/master/docs/getting-started.md).

Run `npm install` within the project directory to install the dependencies listed in the `package.json` file.

---

### I'm new to using Sass, where can I learn more?
[Sass](http://sass-lang.com/) is a CSS preprocessor that essentially allows developers to make use of features that aren't currently available using vanilla CSS. Though Sass file look familiar, `.scss` files found in the src directory output to `.css` files in the `build` directory while making use of variables, mixins, and functions.
The Digital Lexicon makes use of some intermediate functions and mixins. Take a look at [this article about control directives](http://thesassway.com/intermediate/if-for-each-while) if something unfamiliar comes up.
