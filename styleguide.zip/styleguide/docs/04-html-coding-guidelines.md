---
title: HTML Coding Guidelines
label: HTML Coding Guidelines
status: ready
---


- When naming wrappers/containers, use the one that best describes based on example below:
  > A **container** is generally used for structures that can contain more than one element.

  > A **wrapper** is something that wraps around a single object

```html
<div class="items-container">
  <div class="item-wrapper">
    <div class="item">...</div>
  </div>

  <div class="item-wrapper">
    <div class="item">...</div>
  </div>

  <div class="item-wrapper">
    <div class="item">...</div>
  </div>

  <div class="item-wrapper">
    <div class="item">...</div>
  </div>

  <div class="item-wrapper">
    <div class="item">...</div>
  </div>
</div>
```

- Use soft tabs with two spaces — they're the only way to guarantee code renders the same in any environment.
- Never use inline styles *(except when doing HTML emails)*
- Never use inline Javascript
  - Consider placing Javascript files at the bottom of a file before the closing `</body>` tag
- Nested elements should be indented once
- Use lowercase tag names.
- Always use double quotes, never single quotes, on attributes.
- Don’t omit optional closing tags (e.g. `</li>` or `</body>`).
- Items in list form should always be housed in a `ul`, `ol`, or `dl` never a set of `div` or `p`.
- Use `label` fields to label each form field, the `for` attribute should associate itself with the input field via its `id` attribute, so users can click on labels and enter the associated field
- Place an empty line between sibling elements, for example:

```html
<div class="component">
  <h3>A heading of some sort</h3>

  <button class="component__button button">Click Me</button>
</div>

<div class="component">
  <button class="component__button button">No, Click Me</button>
</div>
```

- Tables should never be used for page layout.
- HTML attributes should come in this particular order for easier reading of code.
  - `class`
  - `id, name`
  - `data-*`
  - `src, for, type, href, value`
  - `title, alt`
  - `aria-*, role`

### Examples:
```html
<div class="class-first" id="then-id" data-name="name"></div>

<a class="button" href="#">Click me</a>

<img class="class" src="../../src" title="Title" alt="alternate text for screen reader" />

<form class="form form--primary" method="post">
  <label for="name">Name</label>

  <input class="form__input form__input--text" name="name" id="name" type="text" placeholder="I'm a text field"></input>

  <input class="form__input form__input--submit" name="name" type="submit">Click Me</input>
</form>
```
