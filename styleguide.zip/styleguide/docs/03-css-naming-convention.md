---
title: CSS Naming Convention
label: CSS Naming Convention
status: ready
---

Writing re-usable and intentional styles requires a concerted effort to keep components separate and logical. In order to do so across a large code-base, using a naming convention is a requirement to prevent unintended cascading behavior and to allow code to remain understandable across components, features, and pages.

The naming convention is based on [BEM](http://getbem.com/) and [SuitCSS](https://github.com/suitcss/suit/blob/master/doc/naming-conventions.md), taking advantage of the modularity of these approaches while ideally reducing the complxity of the code-base through consistent class naming.

The naming convention divides classes in to several categories:


- [Global Namespace](#global-namespace)
- [Class Prefixes](#class-prefixes)
- [Utilities](#utilities)
- [Components](#components)
- [Component Descendants](#component-descendants)
- [Component Modifiers](#component-modifiers)
- [States](#states)

---

## Global Namespace
All classes associated with the Lexicon are prefixed with a global namespace, which is **lx** followed by a hyphen:

```scss
.lx-[name] {

}
```

### Class prefixes
In addition to a global namespace, we added prefixes to each class to make it more apparent what job that class is doing. Here’s what class prefixes we landed on:

  - `is-` and `has-` for specific states, such as `.is-active` or `.is-disabled`. These state-based classes would apply to state controlled by JavaScript.
  - `js-` for targeting JavaScript-specific functionality, such as `.js-lx-modal-trigger`. No styles are bound to these classes; they’re reserved for behavior only. For most cases, these `js-` classes would toggle state-based classes to an element.


### Utilities
Utilities are used as global class names that are used universally across platforms and apply specific, re-usable properties distinct from their context.

#### Examples

```scss
.lx-float--left {
  float: left;
}
```

```html
<aside class="primary">
  <p class="primary__content lx-float--left">I float left, but still have other properties independent of the utility class!</p>
</aside>
```

---

### Components
Components are intended to be re-usable and standalone blocks of code that function independently. Ideally by coding in this way, different components can be re-used not only within BB&amp;T platforms but between them.

#### Sample component parent
Components each have their own class name, and when comprised of multiple words, are separated by a `-`.

```scss
.lx-awesome-button {
  display: block;
  padding: 15px 25px;
  border-radius: 3px;
  border: 1px solid #000;
  cursor: pointer;
  background: #fff;
}
```

```html
<a class="lx-awesome-button">Click me</a>
```

### Component Descendants
Descendants of components are clearly labeled and given class names that show their dependence on the parent, yet do *not* rely on nesting.

Each descendant includes the parent component name followed by `__` (that's *two* underscores). Much like the parents, the descendants that are comprised of multiple words are separated by `-`.

```scss
.lx-button__icon {
  margin-right: 5px;
}

.lx-button__text {
  text-transform: uppercase;
  text-shadow: 0 1px 2px rgba(#000, 0.3);
}

.lx-button__text-wrapper {
  max-width: 75%;
}
```

```html
<a class="lx-button">
  <i class="lx-button__icon lx-button__icon--pacman"></i>
  <span class="lx-button__text">Click me</span>
</a>
```

*NOTE - With regards to components and descendants, all descendants are subsets of the parent component.*

For example:

```html
<div class="lx-component">
  <h1 class="lx-component__header">Lorem ipsum dolor sit</h1>

  <div class="lx-component__sub-wrapper">
    <p class="lx-component__paragraph">Nunc bibendum semper metus.</p>
  </div>
</div>
```

### Component Modifiers
Both components and their descendants have the ability to be modified. Following the name of the parent or descendant, the modifier follows after `--`.

```scss
.lx-button--primary {
  background: #eb5252;
  border: 1px solid #a33939;
}

.lx-button--secondary {
  background: #24a353;
  border: 1px solid #19733a;
}
```

*NOTE - when a modifier is used, the component class is still applied - the modifying class is applied in addition to the base component class.*

```html
<a class="lx-button lx-button--primary">
  <i class="lx-button__icon lx-button__icon--pacman"></i>
  <span class="lx-button__text">Click me</span>
</a>

<a class="lx-button lx-button--secondary">
  <i class="lx-button__icon lx-button__icon--mario"></i>
  <span class="lx-button__text">Click me</span>
</a>
```

---

### States

When using JavaScript to dynamically add and remove classes, state-names have a specific syntax. In this case, `.is-[state]`. For example, with an accordion component, it would have a class of `is-collapsed` when collapsed and `is-expanded` when expanded. This makes it more clear for the developer, and separates dynamic class-names from base styles.

#### State examples

```html
<div class="lx-accordion is-collapsed">
  <div class="lx-accordion__content">
    <p class="lx-accordion__paragraph">I'm hidden!</p>
  </div>
</div>
```

```html
<div class="lx-accordion is-expanded">
  <div class="lx-accordion__content">
    <p class="lx-accordion__paragraph">I'm no longer hidden!</p>
  </div>
</div>
```
