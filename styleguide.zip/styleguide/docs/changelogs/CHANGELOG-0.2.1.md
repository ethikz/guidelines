# Digital Lexicon

## 0.2.0  ( Wed Nov 01 2017 12:05:31 GMT-0400 (EDT) )


## Features

  - **button**
    - add conditional to check if button icon classes are defined 

 (217533aa363cd1cab5ef78b7d88c156f772c3536 )    - Add conditional to button screen reader only text and ability to add classes to button icons 

 (0cb1eca41fc1603426584bd3df5966b5950661ef )
  - **close-button**
    - remove title attribute and add aria-label 

 (56e013e4379acac74725eaf08437b6bd4d90df63 )
  - **grid**
    - Fixing import statements and classes to ensure Grid.js does not produce syntax errors 

 (81e1b5fb25f7446248e59597ac088e36541a0457 )
  - **icon**
    - add focusable false to support ie11 and add accessibility attributes to svg 

 (5db56bc9443e7ecec8ec4586856a23c7c41316ab )
  - **modal**
    - Fixing import statement to import $CONTENT and $BODY selectors, fixing issue causing overlay not to appear 

 (8df4d5ec03c6fe9b61505c89a8a99dffc83f8084 )
  - **panel**
    - Fixing Safari defect in which panel buttons have unintended margin 

 (c76d30355b2dae535d644d290605596d6ce5dbce )
  - **switch**
    - Add switch component 

 (c8bab708e92b7839ce170e349d351f7441de61b4 )
  - **table**
    - Add responsive and accessible table component. 

 (4f553d6a292f8b6607644c7fdfd21b8b330f5099 )
  - **tabs**
    - Add tab component 

 (d54a1100e202dd153d988674eabc91f55d2220f6 )
  - **tooltip**
    - Adjusting import to import appropriate module and support older browsers 

 (971e0365e2dbf5ea1fb9624cb967e1ea5129f7b3 )



## Documentation

  - **readme**
    - add git commit guidelines for better readability and changelog creation 

 (0415ea96b454a3317ab9e68903fc114cf429923a )



## Chore

  - **build**
    - Add static analysis tool code climate 

 (efc48562c3206c2f725cefe48c0cd6b87e37c8e0 )
  - **changelog**
    - add bash script to post message into flow for each new release 

 (b675f6cc1970f5c52d933455a9307e9a0e5612d6 )    - remove blacklisted gulp-run for gulp-exec to fix git commands 

 (6387bdcc4ae060cd8a96fd764bea696470aa8770 )    - add npm packages to help automate creation of changelogs 

 (94b5bdb18e1cfaad64c619403e3252801a1f549c )    - remove changelog from root and create a new changelog with tag in the docs folder 

 (2d00d73e90bb70122ab89957b95258817258c462 )    - add npm packages to help automate creation of changelogs 

 (e9fa4b391932a758406ba4d14777d9644f861116 )
  - **fractal**
    - add concat helper to combine classes 

 (f2b260b841cca1693a77f8637b24f9aed234e379 )
  - **gulp**
    - Remove unused task for codeclimate 

 (698a2069c1961db3f70b9415a958b8cf31c0d6d6 )    - switch webpack task to use gulp-exec instead of run 

 (e043a243b599ed5da1916fe07e8019d01d568f37 )
  - **gulpfile**
    - add back tasks for pushing and releasing I removed in previous commit 

 (58498bff24146fdcdc5c55fb9e949ff8e4bbd7db )
  - **mandelbrot**
    - custom JS now controls sidebar navigation, making all sections closed by default on page load 

 (1add9e9bfdf828c4d6b45d408015bce909dbe697 )
  - **npm**
    - remove unused packages and update other packages 

 (691de86fc49f99a051f3a34ea7acfbffbd21925f )
  - **package**
    - Removing Modernizr build script from package.json as Webpack modernizr loader now addresses 

 (9ae335c4c47198d039406eefd366c5d29f620e15 )    - update package-lock from webpack merge 

 (92beacf797f1689150edd0a23c79b48f898979c0 )



## Branches merged
  - Merge branch origin/developers/nick into master 

 (996919a3b84cd4f64e75bc41c405586d8a4d0ab3 )  - Merge branch origin/core/webpack into master 

 (26c044e2449bebc4ede715462fda6925d1860b74 )  - Merge branch 'master' into developers/nick 

 (6cb4c083c0ed22cbb94c4fa7954700e428c1cf0c )  - Merge branch 'master' into core/releases-fix 

 (12c44e783838a825802ba7ff79b3b1354dcd80d3 )  - Merge branch 'core/webpack' of 70.63.134.210:lexicon-master into core/webpack 

 (22216fd4f98eafbf7221116eab5d91185eec8c99 )  - Merge branch 'master' into developers/nick 

 (87b7a94259c5f2ac57b223c4130e54d0227f3850 )  - Merge branch 'core/webpack' of 70.63.134.210:lexicon-master into core/webpack 

 (e918dc39392be00bf09c1ab26b69a95c5e10253c )  - Merge branch 'master' into core/webpack 

 (e9e59b5548bef380eacc4a72da7abd17a4ed6d38 )  - Merge branch 'master' into components--dev/webpack 

 (f42995315198a7dc9b0054a0bb377d100d720df8 )  - Merge branch 'master' into developers/nick 

 (b28685d549fc5d3c7b826c2dc8d205052157521a )




