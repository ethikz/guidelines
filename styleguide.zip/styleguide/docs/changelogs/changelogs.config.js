module.exports = {
  'status': 'changelog'
}
