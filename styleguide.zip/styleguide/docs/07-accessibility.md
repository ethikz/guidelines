---
title: Accessibility
---

The Digital Lexicon framework follows common web standards and—with minimal extra effort—can be used to create web pages that meet the Web Content Accessibility Guidelines (WCAG) 2.0 AA standard.

## What is Accessibility?

Web accessibility ensures that users with disabilities can perceive, understand, navigate, interact with, and contribute to a website as a whole. This means that pages are [Perceivable, Operable, Understandable and Robust](https://www.w3.org/TR/WCAG20/). This includes providing keyboard interaction alternatives for all mouse-based actions, properly identifying all form fields and buttons, providing text based alternatives for all images, videos, icons and SVGs, as well as building components that properly convey their identity, operation model, and state to assistive technologies.

Digital Lexicon provides a set of semantically correct components, each with appropriate [ARIA](https://www.w3.org/TR/wai-aria/) markup so they can be identified correctly to users of assistive technologies.

## Standards Compliant Markup

A combination of semantic markup and use of ARIA roles that are both based on W3C standards and industry best practices will be used in our components.

## Keyboard Navigation

When HTML alone cannot facilitate keyboard navigation, javascript will be used withou our components to allow users to traverse our pages with only a keyboard. Pages will be created with proper navigational link structure and heading hierarchy to facilitate navigation within pages and across the site.

## Appropriate Use of Color

Our components will follow the two main rules of accessibility as it relates to color:

*   We never use color as the only means of providing information or requesting an action.
*   The combinations of text and their background colors do not fall below the [WCAG recommended threshold](https://www.w3.org/TR/UNDERSTANDING-WCAG20/visual-audio-contrast-contrast.html) ratio of 4.5:1 for standard or small text and 3:1 for larger text.

## Images and Icons

Necessary text-based alternatives will be provided for images, icons and SVGs.

## Accessible Forms

All form elements will use proper accessibility compliant markup to provide a complete experience to users with disabilities.

## Interactive Components

Based on [ARIA Authoring Practices](http://w3c.github.io/aria/practices/aria-practices.html), complex interactive components will provide attributes that are understandable by screen reader users on key page elements, with updates to those attributes as necessary with changes in state.

## Resources

*   [W3C Web Accessibility Initiative](https://www.w3.org/WAI/)
*   [WAI-ARIA Authoring Practices](http://w3c.github.io/aria/practices/aria-practices.html)
*   [7 Things Every Designer Needs to Know about Accessibility](https://medium.com/salesforce-ux/7-things-every-designer-needs-to-know-about-accessibility-64f105f0881b#.o8n02j9rr)
*   [Accessible Interface Design: on designing with accessible color contrast ratios](https://medium.com/salesforce-ux/accessible-interface-design-d80e95cbb2c1#.i5tl6ffv3)
*   [WebAIM](http://webaim.org/)
*   [The A11Y Project](http://a11yproject.com/)
*   [Role-based accessibility checklist from Vox Media](http://accessibility.voxmedia.com/)