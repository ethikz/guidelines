---
title: Composing Templates
status: ready
---

The Lexicon makes use of Handlebars [partials](http://handlebarsjs.com/partials.html) and [extend](https://github.com/shannonmoeller/handlebars-layouts#extend-partial-context-keyvalue-) functionality

## Handlebar Partials
Partials allow developers to include component templates on a page based on a template `.hbs` file. In doing so, the developer can then pass in strings, and even short bits of HTML, where different parameters are allowed.

### Usage
In `partials/button.hbs`:

```html
<button class="button">\{{ mainContent }}</button>
```

On `pages/index.hbs`:

```html
<div class="wrapper">
  \{{> button mainContent="Click Me" }}
</div>
```

## Handlebars Extend
`\{{#extend}}` allows developers to create components that can contain other component partials or HTML. For example, a modal. Use `\{{#extend}}` instead of a simple partial when dealing with complex components.

### Usage
In `partials/modal.hbs`:

```html
<div class="modal" id="\{{ id }}">
  \{{#block 'mainContent'}}\{{/block}}
</div>
```

On `pages/index.hbs`

```html
\{{#extend 'modal' id="my-modal" }}
  \{{#content 'mainContent'}}
    <h3>Some HTML can go here</h3>

    <p>You can even use other Handlebars components.</p>

    \{{> button mainContent="A Modal Button" }}
  \{{/content}}
\{{/extend}}
```

---

### Template Standards
When writing Handlebars templates, certain standards should be followed, so that developers can come to expect parameters (and their names) predictably.

#### Common parameters
- `classes` used for `class="button \{{ classes }}"`
- `id` used for `id="\{{ id }}"`
- `attr` used for `<button \{{{ attr }}}>Click Me</button>`
- `mainContent` is used for inner content, typically HTML, of an element, eg: `<button>\{{{ mainContent }}}</button>`
- When using an `\{{#each}}` loop for presentational purposes within the library, be sure to wrap it within an `\{{#if preview}}\{{/if}}` statement, with a regular, re-usable version of the component following the enclosed `\{{else}}`

#### Additional Guidance
- Where possible, use data conditionally, such as`\{{id}} id="\{{this}}"\{{/id}}` - this ensures that the attribute only renders when appropriate data is passed in to the template
- When naming parameters, use [camelCase](https://en.wikipedia.org/wiki/Camel_case) so that JavaScript config files can be utilized
- Think ahead! - Lexicon components need enough flexibility to be usable in a wide variety of situations, without being so flexible that they lose their consistency between projects
