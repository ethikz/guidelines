module.exports = ( gulp, cb ) => {
  return gulp.src( [
    'build',
    'app/public',
    'modules/css',
    'modules/scss'
  ], {
    read: false
  })
    .pipe( plugin.clean() )
    .on( 'error', mapError );
};
