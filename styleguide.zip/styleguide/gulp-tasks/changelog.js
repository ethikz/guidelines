module.exports = ( gulp, cb ) => {
  return gulp.src( './docs/changelogs/', {
    buffer: false
  })
    .pipe( plugin.conventionalChangelog({
      preset: 'angular'
    }) )
    .pipe( plugin.exec( 'git-changelog -r git@server:repo' ) )
    .on( 'end', function() {
      var source = fs.createReadStream( './docs/changelogs/CHANGELOG.md' ),
          target = fs.createWriteStream( './docs/changelogs/CHANGELOG-' + version + '.md' );

      source.pipe( target );

      fs.unlink( './docs/changelogs/CHANGELOG.md', function( err ) {
        if ( err ) {
          gutil.log( mapError );
        }
      })

      changerc.version_name = '' + version + '';

      fs.writeFile( './.changelogrc', JSON.stringify( changerc, null, ' ' ) );
    })
};
