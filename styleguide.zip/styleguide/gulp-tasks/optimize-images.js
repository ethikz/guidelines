module.exports = ( gulp, cb ) => {
  return gulp.src( 'app/images/**.{jpg, png}' )
    .pipe( gulp.dest( 'app/public/images' ) )
    .pipe( plugin.connect.reload() )
    .on( 'error', mapError );
};
