module.exports = ( gulp, cb ) => {
  gulp.watch( 'app/modules', [ 'optimize-svgs', 'optimize-images', 'copy-images', 'fractal:build' ] );
  gulp.watch( 'app/**/*.scss', [ 'scss', 'scss-lint', 'fractal:build' ] );
  gulp.watch( 'app/images/**', [ 'optimize-svgs', 'optimize-images', 'clean-images', 'copy-images', 'fractal:build' ] );
  gulp.watch( 'app/css/theme.scss', [ 'theme-scss', 'fractal:build' ] );
  gulp.watch( 'app/theme/js/**/*.js', [ 'theme-js', 'fractal:build' ] );
  gulp.watch( [ 'app/js/**/*.js', 'app/modules/**/*.js' ], [ 'js-lint', 'javascript' ] );
};
