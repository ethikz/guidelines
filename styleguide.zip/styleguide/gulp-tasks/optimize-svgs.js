module.exports = ( gulp, cb ) => {
  return gulp.src( 'app/images/**.svg' )
    .pipe( plugin.svgmin() )
    .pipe( gulp.dest( 'app/public/images' ) )
    .pipe( plugin.connect.reload() )
    .on( 'error', mapError );
};
