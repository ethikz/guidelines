module.exports = ( gulp, cb ) => {
  return gulp.src( 'app/css/main.scss' )
    .pipe( plugin.changed( 'modules/css' ) )
    .pipe( plugin.sassGlob() )
    .pipe( plugin.sass() )
    .pipe( plugin.sourcemaps.init() )
    .pipe( plugin.autoprefixer( 'last 2 versions' ) )
    .pipe( plugin.cleanCss() )
    .pipe( gulp.dest( 'modules/css' ) )
    .pipe( plugin.sourcemaps.write( '.' ) )
    .pipe( gulp.dest( 'app/public/css' ) )
    .pipe( plugin.connect.reload() )
    .on( 'end', function() {
      return gulp.src( 'app/css/main.scss' )
        .pipe( gulp.dest( 'modules/components' ) )
    })
    .on( 'error', mapError );
};
