module.exports = ( gulp, cb ) => {
  return gulp.src( 'app/public/images' )
    .pipe( plugin.clean() )
    .pipe( plugin.connect.reload() )
    .on( 'error', mapError );
};
