module.exports = ( gulp, cb ) => {
  return gulp.src( [
    'app/modules/**/**/!(_*.hbs|*.config.js|*.md)',
    '!app/modules/1-settings/**/*.hbs',
    '!app/modules/4-elements/**/*.hbs',
    '!app/modules/5-objects/preview-icon{,/**/*}',
    '!app/modules/7-trumps/flexbox/*.hbs'
  ] )
    .pipe( gulp.dest( './modules/components' ) )
    .on( 'end', function() {
      return plugin.glob( 'modules/**/!(_)*.hbs', function( er, files ) {
        mkdirp( path.join( __dirname, '../modules/components/' ), function( err ) {
          if ( err ) {
            mapError( err );
          }
        });

        files.forEach( function( file ) {
          fs.readFile( file, 'utf-8', function( err, content ) {
            if ( err ) {
              return mapError( err );
            }

            var result = content.replace( /{{~?>\s?@/gm, '{{> ' );

            try {
              fs.writeFile( file, result, 'utf8', function( err ) {
                if ( err ) {
                  return mapError( err );
                }
              })
            } catch ( e ) {
              gutil.log( 'Can not write to file' + e );
            }
          });
        });
      });
    })
    .on( 'error', mapError );
};
