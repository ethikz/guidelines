module.exports = ( gulp, cb ) => {
  return gulp.src( './modules/package.json' )
    .pipe( plugin.bump({
      type: 'patch'
    }) )
    .pipe( gulp.dest( './modules' ) )
    .on( 'error', mapError );
};
