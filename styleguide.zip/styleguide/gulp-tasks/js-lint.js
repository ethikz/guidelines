module.exports = ( gulp, cb ) => {
  function embolden( text ) {
    return `\u001b[1m${text}\u001b[22m `;
  }

  function pluralish( count, text ) {
    return `${count} ${text}${count === 1 ? '' : 's'}`;
  }

  return gulp.src( [
    './*.js',
    '!./entity.js',
    'app/js/**/*.js',
    'app/modules/**/*.js',
    '!app/modules/**/*.config.js'
  ] )
    .pipe( plugin.changed( 'app/**/*.js' ) )
    .pipe( plugin.eslint() )
    .pipe( plugin.eslint.format( results => {
      return embolden( '[Custom ESLint Summary]' ) + pluralish( results.length, 'File' ) + ', ' + pluralish( results.errorCount, 'Error' ) + ', and ' + pluralish( results.warningCount, 'Warning' )
    }) )
    .pipe( plugin.eslint.format( 'checkstyle', fs.createWriteStream( 'reports/jslint.xml' ) ) )
    .pipe( plugin.eslint.failAfterError() )
    .pipe( plugin.connect.reload() )
    .on( 'error', mapError );
};
