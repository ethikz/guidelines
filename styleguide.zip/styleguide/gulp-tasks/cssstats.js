module.exports = ( gulp, cb ) => {
  return gulp.src( 'app/public/css/main.css' )
    .pipe( plugin.stylestats({
      type: 'html',
      outfile: true
    }) )
    .pipe( plugin.rename({
      suffix: newdate
    }) )
    .pipe( gulp.dest( './stats/' ) )
    .pipe( plugin.open({
      app: browser
    }) )
    .on( 'error', mapError );
};
