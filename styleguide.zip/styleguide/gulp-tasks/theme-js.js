module.exports = ( gulp, cb ) => {
  return gulp.src( [
    'node_modules/jquery/dist/jquery.js',
    'node_modules/clipboard/dist/clipboard.min.js',
    'theme-overrides/assets/js/*.js'
  ] )
    .pipe( plugin.changed( 'app/public/js/' ) )
    .pipe( plugin.concat( 'theme.min.js' ) )
    .pipe( gulp.dest( 'app/public/js' ) )
    .pipe( plugin.connect.reload() )
    .on( 'error', mapError );
};
