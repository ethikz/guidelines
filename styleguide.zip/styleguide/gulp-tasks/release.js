module.exports = ( gulp, cb ) => {
  return gulp.src( './modules/**/*' )
    .pipe( plugin.ghPages({
      remoteUrl: 'git@server:repo',
      branch: 'master',
      force: true
    }) )
    .on( 'error', mapError );
};
