module.exports = ( gulp, cb ) => {
  return gulp.src( 'theme-overrides/assets/scss/theme.scss' )
    .pipe( plugin.changed( 'app/public/css' ) )
    .pipe( plugin.sass() )
    .pipe( plugin.sourcemaps.init() )
    .pipe( plugin.autoprefixer( 'last 2 versions' ) )
    .pipe( plugin.cleanCss() )
    .pipe( plugin.sourcemaps.write( '.' ) )
    .pipe( gulp.dest( 'app/public/css' ) )
    .pipe( plugin.connect.reload() )
    .on( 'error', mapError );
};
