module.exports = ( gulp, cb ) => {
  return gulp.src( 'node_modules/font-awesome/fonts/**/*' )
    .pipe( gulp.dest( 'app/public/fonts' ) )
    .pipe( plugin.connect.reload() )
    .on( 'error', mapError );
};
