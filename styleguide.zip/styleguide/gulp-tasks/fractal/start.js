module.exports = ( gulp, fractal, cb ) => {
  const server = global.fractal.web.server({
    sync: true
  });
  const logger = global.fractal.cli.console;

  server.on( 'error', err => logger.error( err.message ) );

  return server.start().then( () => {
    logger.success( `Fractal server is now running at ${server.url}` );
    logger.success( `Network URL: ${server.urls.sync.external}` );
  });
};
