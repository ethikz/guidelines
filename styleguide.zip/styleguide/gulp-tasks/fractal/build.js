module.exports = ( gulp, fractal, cb ) => {
  const builder = global.fractal.web.builder();
  const logger = global.fractal.cli.console;

  builder.on( 'progress', ( completed, total ) => logger.update( `Exported ${completed} of ${total} items`, 'info' ) );
  builder.on( 'error', err => logger.error( err.message ) );

  return builder.build().then( () => {
    logger.success( 'Fractal build completed!' );
  }).then( () => {
    if ( config.env === 'staging' ) {
      gulp.run( 'staging' );
    }
  })
};
