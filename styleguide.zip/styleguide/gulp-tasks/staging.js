module.exports = ( gulp, cb ) => {
  return gulp.src( './build/index.html', function( er, files ) {
    files.forEach( function( file ) {
      fs.readFile( file, 'utf-8', function( err, content ) {
        if ( err ) {
          return mapError( err );
        }

        if ( content.match( '../?|../../?' ) ) {
          result = content.replace( /\.\.\/?|\.\.\/\.\.\/?/gm, '' );

          try {
            fs.writeFile( file, result, 'utf8', function( err ) {
              if ( err ) {
                return mapError( err );
              }
            })
          } catch ( e ) {
            gutil.log( 'Can not write to file' + e );
          }
        }
      });
    })
  })
    .on( 'end', function() {
      return gulp.src( './build/docs/*.html', function( er, files ) {
        files.forEach( function( file ) {
          fs.readFile( file, 'utf-8', function( err, content ) {
            if ( err ) {
              return mapError( err );
            }

            if ( content.match( '../../?' ) ) {
              result = content.replace( /\.\.\/\.\.\/?/gm, '../' );

              try {
                fs.writeFile( file, result, 'utf8', function( err ) {
                  if ( err ) {
                    return mapError( err );
                  }
                })
              } catch ( e ) {
                gutil.log( 'Can not write to file' + e );
              }
            }
          });
        });
      })
    })
    .on( 'end', function() {
      return gulp.src( './build/components/**/*.html', function( er, files ) {
        files.forEach( function( file ) {
          fs.readFile( file, 'utf-8', function( err, content ) {
            if ( err ) {
              return mapError( err );
            }

            if ( content.match( '<use?' ) ) {
              result = content.replace( /\/icons\/?/gm, '../../icons/' );

              try {
                fs.writeFile( file, result, 'utf8', function( err ) {
                  if ( err ) {
                    return mapError( err );
                  }
                })
              } catch ( e ) {
                gutil.log( 'Can not write to file' + e );
              }
            }
          });
        });
      })
    })
    .on( 'end', function() {
      return gulp.src( './build/css/*.css', function( er, files ) {
        files.forEach( function( file ) {
          fs.readFile( file, 'utf-8', function( err, content ) {
            if ( err ) {
              return mapError( err );
            }

            if ( content.match( '../../icons?' ) ) {
              result = content.replace( /\.\.\/\.\.\/icons?/gm, '../icons' );

              try {
                fs.writeFile( file, result, 'utf8', function( err ) {
                  if ( err ) {
                    return mapError( err );
                  }
                })
              } catch ( e ) {
                gutil.log( 'Can not write to file' + e );
              }
            }
          });
        })
      })
    })
    .pipe( plugin.connect.reload() )
    .on( 'error', mapError );
};
