module.exports = ( gulp, cb ) => {
  return gulp.src( './modules/package.json' )
    .pipe( plugin.exec( 'git add modules/package.json' ) )
    .pipe( plugin.exec( 'git commit -m "Update Lexicon to release ' + version + '"' ) )
    .on( 'end', function() {
      plugin.exec( 'sh ./release-notification' )
    })
    .on( 'error', mapError );
};
