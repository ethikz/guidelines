module.exports = ( gulp, cb ) => {
  return gulp.src( [
    'app/js/**/**/*.js',
    'app/modules/**/**/!(*.config).js'
  ], {
    passthrough: true
  })
    .pipe( plugin.changed( 'app/public/js/' ) )
    .pipe( plugin.exec( 'npm run webpack', function( err, stdout, stderr ) {
      gutil.log( stdout )
      cb( null );
    }) )
    .pipe( plugin.connect.reload() )
    .on( 'error', mapError )
};
