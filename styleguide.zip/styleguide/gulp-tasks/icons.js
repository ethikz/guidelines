module.exports = ( gulp, cb ) => {
  return gulp.src( 'app/modules/5-objects/_icon/svgs/**/*.svg' )
    .pipe( plugin.newer( 'app/modules/5-objects/_icon/svgs/**/*.svg' ) )
    .pipe( gulp.dest( 'app/public/icons' ) )
    .pipe( plugin.svgSprites ({
      mode: 'symbols',
      preview: false
    }) )
    .pipe( gulp.dest( 'app/public/icons' ) )
    .pipe( plugin.connect.reload() )
    .on( 'error', mapError );
};
