module.exports = ( gulp, cb ) => {
  return gulp.src( [
    'app/**/*.scss',
    'theme-overrides/assets/scss'
  ] )
    .pipe( plugin.scssLint({
      'config': '.scss-lint.yml',
      'maxBuffer': 307200,
      'filePipeOutput': 'scss-lint-report.xml'
    }) )
    .pipe( gulp.dest( './reports' ) )
    .pipe( plugin.connect.reload() )
    .on( 'error', mapError );
};
