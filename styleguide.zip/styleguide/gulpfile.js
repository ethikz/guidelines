/* eslint-disable no-useless-concat */

$ = require( './node_modules/jquery/dist/jquery.min.js' );
Clipboard = require( './node_modules/clipboard/dist/clipboard.min.js' );
gulp = require( 'gulp' );
path = require( 'path' );
runSequence = require( 'run-sequence' ).use( gulp );
gulpRequireTasks = require( 'gulp-require-tasks' );
gutil = require( 'gulp-util' );
fs = require( 'fs' );
chalk = require( 'chalk' );
fractal = require( './fractal.js' );
config = JSON.parse( fs.readFileSync( path.resolve( __dirname, 'gulp-config.json' ) ) );
browserSync = require( 'browser-sync' );
reload = browserSync.reload;
os = require( 'os' );
dateObj = new Date();
browser = os.platform() === 'linux' ? 'google-chrome' : (
  os.platform() === 'darwin' ? 'google chrome' : (
    os.platform() === 'win32' ? 'chrome' : 'firefox' ) );
newdate = '-' + ( dateObj.getUTCMonth() + 1 ) + '-' + dateObj.getUTCDate() + '-' + dateObj.getUTCFullYear() + '-' + dateObj.getHours() + '-' + dateObj.getMinutes() + '-' + dateObj.getSeconds();
version = JSON.parse( fs.readFileSync( './modules/package.json', 'utf8' ) ).version;
changerc = JSON.parse( fs.readFileSync( './.changelogrc' ) )
plugin = require( 'gulp-load-plugins' )({
  camelize: true
});

// fetch command line arguments
arg = ( argList => {
  let arg = {};
  let a;
  let opt;
  let thisOpt;
  let curOpt;

  for ( a = 0; a < argList.length; a++ ) {
    thisOpt = argList[a].trim();
    opt = thisOpt.replace( /^-+/, '' );

    if ( opt === thisOpt ) {
      // argument value
      if ( curOpt ) {
        arg[curOpt] = opt;
      }

      curOpt = null;
    } else {
      // argument name
      curOpt = opt;
      arg[curOpt] = true;
    }
  }

  return arg;
})( process.argv );

global.fractal = fractal;

mapError = function( err ) {
  if ( err.fileName ) {
    // Regular error
    gutil.log( chalk.red( err.name ) +
      ': ' + chalk.yellow( err.fileName.replace( __dirname + '/src/js/', '' ) ) +
      ': ' + 'Line ' + chalk.magenta( err.lineNumber ) +
      ' & ' + 'Column ' + chalk.magenta( err.columnNumber || err.column ) +
      ': ' + chalk.blue( err.description ) );
  } else {
    // Browserify error..
    gutil.log( chalk.red( err.name ) + ': ' + chalk.yellow( err.message ) );
  }
};

gulpRequireTasks({
  passGulp: true
});


// Tasks
// =======================================================
gulp.task( 'default', function( cb ) {
  config.env = arg.env || 'development';

  return runSequence( 'clean', 'scss', 'scss-lint', 'theme-scss', 'theme-js', 'js-lint', 'javascript', 'fonts', 'icons', 'optimize-svgs', 'optimize-images', 'clean-images', 'copy-images', 'fractal:build', 'fractal:start', 'watch', cb );
});

gulp.task( 'rebuild', function( cb ) {
  return runSequence( ['clean'], 'scss', 'scss-lint', 'theme-scss', 'theme-js', 'js-lint', 'javascript', 'fonts', 'icons', 'optimize-svgs', 'optimize-images', 'clean-images', 'copy-images', 'fractal:build', cb );
});

gulp.task( 'stats', function( cb ) {
  return runSequence( 'cssstats', cb );
});

gulp.task( 'build', function( cb ) {
  return runSequence(
    ['clean'],
    [ 'scss', 'scss-lint' ],
    ['bundle-package'],
    ['bump'],
    ['changelog'],
    ['push-version'],
    ['release'],
    function( error ) {
      if ( error ) {
        gutil.log( mapError( error.message ) );
      } else {
        gutil.log( 'RELEASE FINISHED SUCCESSFULLY' );
      }

      cb( error );
    });
});
